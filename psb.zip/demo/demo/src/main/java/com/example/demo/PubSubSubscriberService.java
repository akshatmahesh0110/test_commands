package com.example.demo;

import com.google.cloud.pubsub.v1.AckReplyConsumer;
import com.google.cloud.pubsub.v1.Subscriber;
import com.google.pubsub.v1.ProjectSubscriptionName;
import com.google.pubsub.v1.PubsubMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import org.threeten.bp.Duration;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class PubSubSubscriberService {

    private static final Logger logger = LoggerFactory.getLogger(PubSubSubscriberService.class);
    // Keep a reference to the Subscriber so we can stop it cleanly.
    private final AtomicReference<Subscriber> subscriberRef = new AtomicReference<>();
    @Value("${app.gcp.project-id}")
    private String projectId;
    @Value("${app.gcp.subscription-id}")
    private String subscriptionId;

    /**
     * Start the streaming Subscriber once the application is ready.
     * The Subscriber will automatically extend ack deadlines while processing.
     */
    @EventListener(ApplicationReadyEvent.class)
    public void startSubscriber() {
        String subscriptionName = ProjectSubscriptionName.format(projectId, subscriptionId);
        logger.info("Starting Pub/Sub subscriber for subscription: {}", subscriptionName);

        // MessageReceiver: handle messages as they arrive.
        com.google.cloud.pubsub.v1.MessageReceiver receiver = (PubsubMessage message, AckReplyConsumer consumer) -> {
            try {
                // Access message data and attributes
                String data = message.getData() != null ? message.getData().toStringUtf8() : "";
                logger.info("Received message. id={}, publishTime={}, attributes={}, payload={}",
                        message.getMessageId(), message.getPublishTime(), message.getAttributesMap(), data);

                // TODO: place your processing logic here (idempotent, fast, async-friendly)
                // If processing is synchronous and may take long, ensure the maxAckExtensionPeriod below covers it
                // or offload processing to another executor and ACK after completion.

                // Acknowledge after successful processing
                consumer.ack();
            } catch (Exception ex) {
                logger.error("Error processing message id={}. Nacking so it can be retried.", message.getMessageId(), ex);
                // Nack to allow redelivery (or choose to ack to drop)
                consumer.nack();
            }
        };

        Subscriber subscriber = Subscriber.newBuilder(subscriptionName, receiver)
                // Set a sensible max ack extension period; avoids infinite hold in edge cases.
                .setMaxAckExtensionPeriod(Duration.ofMinutes(10)) // tune for your processing latency
                .build();

        subscriberRef.set(subscriber);
        subscriber.startAsync().awaitRunning();
        logger.info("Pub/Sub subscriber started.");
    }

    /**
     * Stop the subscriber gracefully when the Spring context is closing.
     */
    @EventListener(ContextClosedEvent.class)
    public void stopSubscriber() {
        logger.info("Stopping Pub/Sub subscriber...");
        Subscriber subscriber = subscriberRef.get();
        if (subscriber != null) {
            subscriber.stopAsync();
            try {
                // Wait a short while for orderly shutdown
                subscriber.awaitTerminated(30, TimeUnit.SECONDS);
            } catch (Exception e) {
                logger.warn("Timed out waiting for Pub/Sub subscriber to terminate, forcing stop.", e);
            }
        }
        logger.info("Pub/Sub subscriber stopped.");
    }
}
