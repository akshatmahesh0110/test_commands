package com.scamcheck.modeloutcome.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.cloud.spanner.Key;
import com.scamcheck.modeloutcome.config.ApplicationConstants;
import com.scamcheck.modeloutcome.domain.ScamCheckEvent;
import com.scamcheck.modeloutcome.dto.GcsNotificationMessage;
import com.scamcheck.modeloutcome.repository.ScamCheckEventRepository;
import com.scamcheck.modeloutcome.service.MessageProcessingService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

/**
 * Integration tests for message processing flow.
 *
 * Note: Requires Spanner emulator or test instance configuration.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
@SpringBootTest
@ActiveProfiles("test")
@Transactional
class MessageProcessingIntegrationTest {

    @Autowired
    private MessageProcessingService messageProcessingService;

    @Autowired
    private ScamCheckEventRepository eventRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testProcessMessage_Success() throws Exception {
        // Given
        String sessionId = UUID.randomUUID().toString();
        String idempotencyKey = UUID.randomUUID().toString();

        GcsNotificationMessage message = GcsNotificationMessage.builder()
                .bucket("test-bucket")
                .name("test-object")
                .timeCreated("2025-09-26T01:46:06.939Z")
                .contentType("application/zip")
                .metadata(Map.of(
                        ApplicationConstants.METADATA_SCAM_CHECK_SESSION_ID, sessionId,
                        ApplicationConstants.METADATA_IDEMPOTENCY_KEY, idempotencyKey,
                        ApplicationConstants.METADATA_ORG_ID, "ORG001",
                        ApplicationConstants.METADATA_BRAND, "TestBrand",
                        ApplicationConstants.METADATA_CHANNEL, "WEB"
                ))
                .build();

        String messagePayload = objectMapper.writeValueAsString(message);
        String correlationId = UUID.randomUUID().toString();

        // When
        messageProcessingService.processMessage(messagePayload, correlationId);

        // Then
        await().untilAsserted(() -> {
            Optional<ScamCheckEvent> savedEvent = eventRepository.findBySessionIdAndProducerEventId(
                    sessionId, idempotencyKey);

            assertThat(savedEvent).isPresent();
            assertThat(savedEvent.get().getScamCheckSessionId()).isEqualTo(sessionId);
            assertThat(savedEvent.get().getProducerEventId()).isEqualTo(idempotencyKey);
            assertThat(savedEvent.get().getVersion()).isEqualTo(3L);
            assertThat(savedEvent.get().getEventType()).isEqualTo(ApplicationConstants.EVENT_TYPE_CALL_MODEL);
            assertThat(savedEvent.get().getStatus()).isEqualTo(ApplicationConstants.EVENT_STATUS_IN_PROGRESS);
        });
    }

    @Test
    void testProcessMessage_Idempotency() throws Exception {
        // Given
        String sessionId = UUID.randomUUID().toString();
        String idempotencyKey = UUID.randomUUID().toString();

        GcsNotificationMessage message = GcsNotificationMessage.builder()
                .bucket("test-bucket")
                .name("test-object")
                .timeCreated("2025-09-26T01:46:06.939Z")
                .metadata(Map.of(
                        ApplicationConstants.METADATA_SCAM_CHECK_SESSION_ID, sessionId,
                        ApplicationConstants.METADATA_IDEMPOTENCY_KEY, idempotencyKey,
                        ApplicationConstants.METADATA_ORG_ID, "ORG001",
                        ApplicationConstants.METADATA_BRAND, "TestBrand",
                        ApplicationConstants.METADATA_CHANNEL, "WEB"
                ))
                .build();

        String messagePayload = objectMapper.writeValueAsString(message);
        String correlationId = UUID.randomUUID().toString();

        // When - Process message twice
        messageProcessingService.processMessage(messagePayload, correlationId);
        messageProcessingService.processMessage(messagePayload, UUID.randomUUID().toString());

        // Then - Only one event should exist
        Optional<ScamCheckEvent> savedEvent = eventRepository.findBySessionIdAndProducerEventId(
                sessionId, idempotencyKey);

        assertThat(savedEvent).isPresent();

        // Verify only one record exists in DB
        Key key = Key.of(sessionId, 3L);
        assertThat(eventRepository.existsById(key)).isTrue();
    }
}