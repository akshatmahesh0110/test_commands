package com.scamcheck.modeloutcome.unit;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scamcheck.modeloutcome.config.ApplicationConstants;
import com.scamcheck.modeloutcome.domain.ScamCheckEvent;
import com.scamcheck.modeloutcome.dto.GcsNotificationMessage;
import com.scamcheck.modeloutcome.service.EventTransformerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for EventTransformerService.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
@ExtendWith(MockitoExtension.class)
class EventTransformerServiceTest {

    private EventTransformerService eventTransformerService;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        eventTransformerService = new EventTransformerService(objectMapper);

        // Set configuration values
        ReflectionTestUtils.setField(eventTransformerService, "producerServiceName", "model-outcome-service");
        ReflectionTestUtils.setField(eventTransformerService, "eventType", ApplicationConstants.EVENT_TYPE_CALL_MODEL);
        ReflectionTestUtils.setField(eventTransformerService, "status", ApplicationConstants.EVENT_STATUS_IN_PROGRESS);
        ReflectionTestUtils.setField(eventTransformerService, "version", 3L);
        ReflectionTestUtils.setField(eventTransformerService, "eventVersion", 1L);
    }

    @Test
    void testTransform_Success() {
        // Given
        GcsNotificationMessage message = createTestMessage();

        // When
        ScamCheckEvent result = eventTransformerService.transform(message);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getEventId()).isNotNull();
        assertThat(result.getScamCheckSessionId()).isEqualTo("15d905a8-ec44-4693-b145-e0589b69f28e");
        assertThat(result.getVersion()).isEqualTo(3L);
        assertThat(result.getEventVersion()).isEqualTo(1L);
        assertThat(result.getEventType()).isEqualTo(ApplicationConstants.EVENT_TYPE_CALL_MODEL);
        assertThat(result.getStatus()).isEqualTo(ApplicationConstants.EVENT_STATUS_IN_PROGRESS);
        assertThat(result.getOrgId()).isEqualTo("ORG001");
        assertThat(result.getBrand()).isEqualTo("Lloyds");
        assertThat(result.getChannel()).isEqualTo("WEB");
        assertThat(result.getProducerService()).isEqualTo("model-outcome-service");
        assertThat(result.getProducerEventId()).isEqualTo("315af5d0-4e9f-4e8e-9c0a-0d6140d1c3a1");
        assertThat(result.getEventPayload()).isNotNull();
        assertThat(result.getEventPayload()).doesNotContain("kmsKeyName");
    }

    @Test
    void testCreateEventPayload_ExcludesKmsKeyName() throws Exception {
        // Given
        GcsNotificationMessage message = createTestMessage();

        // When
        ScamCheckEvent result = eventTransformerService.transform(message);

        // Then
        Map<String, Object> payload = objectMapper.readValue(result.getEventPayload(), Map.class);
        assertThat(payload).doesNotContainKey("kmsKeyName");
        assertThat(payload).containsKey("bucket");
        assertThat(payload).containsKey("name");
        assertThat(payload).containsKey("metadata");
    }

    private GcsNotificationMessage createTestMessage() {
        return GcsNotificationMessage.builder()
                .kind("storage#object")
                .id("test-id")
                .name("documents/Lloyds/LYDS/15d905a8-ec44-4693-b145-e0589b69f28e/20250926_014605_pup.zip")
                .bucket("tnt01-ecpcda-bld-01-stb-euwe2-scam-clean")
                .timeCreated("2025-09-26T01:46:06.939Z")
                .contentType("application/zip")
                .size("501322")
                .metadata(Map.of(
                        ApplicationConstants.METADATA_SCAM_CHECK_SESSION_ID, "15d905a8-ec44-4693-b145-e0589b69f28e",
                        ApplicationConstants.METADATA_IDEMPOTENCY_KEY, "315af5d0-4e9f-4e8e-9c0a-0d6140d1c3a1",
                        ApplicationConstants.METADATA_ORG_ID, "ORG001",
                        ApplicationConstants.METADATA_BRAND, "Lloyds",
                        ApplicationConstants.METADATA_CHANNEL, "WEB",
                        ApplicationConstants.METADATA_SOURCE_SYSTEM_ID, "scam-check-document-service"
                ))
                .kmsKeyName("projects/test/locations/europe-west2/keyRings/test/cryptoKeys/test/cryptoKeyVersions/2")
                .build();
    }
}