package com.scamcheck.modeloutcome.unit;

import com.scamcheck.modeloutcome.config.ApplicationConstants;
import com.scamcheck.modeloutcome.dto.GcsNotificationMessage;
import com.scamcheck.modeloutcome.exception.ValidationException;
import com.scamcheck.modeloutcome.validator.MessageValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Unit tests for MessageValidator.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
class MessageValidatorTest {

    private MessageValidator messageValidator;

    @BeforeEach
    void setUp() {
        messageValidator = new MessageValidator();
    }

    @Test
    void testValidate_Success() {
        // Given
        GcsNotificationMessage message = createValidMessage();

        // When/Then
        assertThatCode(() -> messageValidator.validate(message))
                .doesNotThrowAnyException();
    }

    @Test
    void testValidate_MissingMetadata() {
        // Given
        GcsNotificationMessage message = createValidMessage();
        message.setMetadata(null);

        // When/Then
        assertThatThrownBy(() -> messageValidator.validate(message))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining(ApplicationConstants.VALIDATION_MSG_MISSING_METADATA);
    }

    @Test
    void testValidate_MissingSessionId() {
        // Given
        GcsNotificationMessage message = createValidMessage();
        message.getMetadata().remove(ApplicationConstants.METADATA_SCAM_CHECK_SESSION_ID);

        // When/Then
        assertThatThrownBy(() -> messageValidator.validate(message))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining(ApplicationConstants.VALIDATION_MSG_MISSING_SESSION_ID);
    }

    @Test
    void testValidate_InvalidUUID() {
        // Given
        GcsNotificationMessage message = createValidMessage();
        message.getMetadata().put(ApplicationConstants.METADATA_SCAM_CHECK_SESSION_ID, "invalid-uuid");

        // When/Then
        assertThatThrownBy(() -> messageValidator.validate(message))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining(ApplicationConstants.VALIDATION_MSG_INVALID_UUID);
    }

    @Test
    void testValidate_MissingTimeCreated() {
        // Given
        GcsNotificationMessage message = createValidMessage();
        message.setTimeCreated(null);

        // When/Then
        assertThatThrownBy(() -> messageValidator.validate(message))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining(ApplicationConstants.VALIDATION_MSG_MISSING_TIME_CREATED);
    }

    private GcsNotificationMessage createValidMessage() {
        Map<String, String> metadata = new HashMap<>();
        metadata.put(ApplicationConstants.METADATA_SCAM_CHECK_SESSION_ID, "15d905a8-ec44-4693-b145-e0589b69f28e");
        metadata.put(ApplicationConstants.METADATA_IDEMPOTENCY_KEY, "315af5d0-4e9f-4e8e-9c0a-0d6140d1c3a1");
        metadata.put(ApplicationConstants.METADATA_ORG_ID, "ORG001");
        metadata.put(ApplicationConstants.METADATA_BRAND, "Lloyds");
        metadata.put(ApplicationConstants.METADATA_CHANNEL, "WEB");

        return GcsNotificationMessage.builder()
                .bucket("test-bucket")
                .name("test-object")
                .timeCreated("2025-09-26T01:46:06.939Z")
                .metadata(metadata)
                .build();
    }
}