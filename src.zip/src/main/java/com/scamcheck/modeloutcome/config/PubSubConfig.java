package com.scamcheck.modeloutcome.config;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.api.gax.core.CredentialsProvider;
import com.google.api.gax.core.NoCredentialsProvider;
import com.google.auth.Credentials;
import com.google.auth.oauth2.GoogleCredentials;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import java.io.IOException;

/**
 * Configuration for GCP Pub/Sub integration.
 * Uses Application Default Credentials (ADC) for authentication.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
@Slf4j
@Configuration
public class PubSubConfig {

    @Value("${spring.cloud.gcp.project-id}")
    private String projectId;

    /**
     * Configure ObjectMapper for JSON serialization/deserialization.
     *
     * @return configured ObjectMapper
     */
    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();

        // Register JavaTimeModule for Java 8 date/time support
        mapper.registerModule(new JavaTimeModule());

        // Disable writing dates as timestamps
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        // Ignore unknown properties for forward compatibility
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        // Pretty print for readability (disable in production if needed)
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        return mapper;
    }

    /**
     * Configure Google Cloud credentials using ADC.
     *
     * ADC checks credentials in the following order:
     * 1. GOOGLE_APPLICATION_CREDENTIALS environment variable
     * 2. User credentials from gcloud auth application-default login
     * 3. Compute Engine, GKE, Cloud Run service account
     *
     * @return CredentialsProvider
     */
    @Bean
    @Profile("!test") // Exclude from test profile
    public CredentialsProvider credentialsProvider() {
        try {
            Credentials credentials = GoogleCredentials.getApplicationDefault();
            log.info("Successfully loaded Application Default Credentials for project: {}", projectId);
            return () -> credentials;
        } catch (IOException e) {
            log.error("Failed to load Application Default Credentials", e);
            throw new IllegalStateException("Failed to load ADC. Please configure GOOGLE_APPLICATION_CREDENTIALS", e);
        }
    }

    /**
     * No-op credentials provider for test profile.
     *
     * @return NoCredentialsProvider
     */
    @Bean
    @Profile("test")
    public CredentialsProvider testCredentialsProvider() {
        log.info("Using NoCredentialsProvider for test profile");
        return NoCredentialsProvider.create();
    }
}