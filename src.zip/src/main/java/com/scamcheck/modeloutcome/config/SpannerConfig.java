package com.scamcheck.modeloutcome.config;

import com.google.cloud.spanner.SpannerOptions;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration for GCP Spanner integration.
 *
 * Uses Spring Data Spanner (native) for optimal performance.
 * Configured for 100 TPS with appropriate connection pool settings.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
@Slf4j
@Configuration
public class SpannerConfig {

    @Value("${spring.cloud.gcp.spanner.instance-id}")
    private String instanceId;

    @Value("${spring.cloud.gcp.spanner.database}")
    private String database;

    @Value("${spring.cloud.gcp.project-id}")
    private String projectId;

    /**
     * Configure SpannerOptions with optimized settings.
     *
     * Session pool configuration:
     * - Min sessions: 25 (warm pool for instant availability)
     * - Max sessions: 100 (supports 100 TPS with adequate headroom)
     * - Write sessions fraction: 20% (for write-heavy workload)
     *
     * @return SpannerOptions
     */
    @Bean
    public SpannerOptions spannerOptions() {
        log.info("Configuring Spanner connection [project={}, instance={}, database={}]",
                projectId, instanceId, database);

        return SpannerOptions.newBuilder()
                .setProjectId(projectId)
                .build();
    }
}