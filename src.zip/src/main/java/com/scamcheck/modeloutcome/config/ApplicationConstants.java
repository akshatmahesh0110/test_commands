package com.scamcheck.modeloutcome.config;

/**
 * Centralized constants for the Model Outcome Microservice.
 * Follows 12-factor app methodology for configuration management.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
public final class ApplicationConstants {

    private ApplicationConstants() {
        throw new UnsupportedOperationException("Utility class - cannot be instantiated");
    }

    // ==================== Event Type Constants ====================
    public static final String EVENT_TYPE_CALL_MODEL = "CALL_MODEL";
    public static final String EVENT_STATUS_IN_PROGRESS = "IN-PROGRESS";
    public static final String EVENT_STATUS_FAILED = "FAILED";
    public static final int EVENT_VERSION_DEFAULT = 1;
    public static final int VERSION_CALL_MODEL = 3;

    // ==================== Spanner Column Names ====================
    public static final String COLUMN_EVENT_ID = "event_id";
    public static final String COLUMN_SCAM_CHECK_SESSION_ID = "scam_check_session_id";
    public static final String COLUMN_VERSION = "version";
    public static final String COLUMN_EVENT_TIMESTAMP = "event_timestamp";
    public static final String COLUMN_EVENT_VERSION = "event_version";
    public static final String COLUMN_EVENT_TYPE = "event_type";
    public static final String COLUMN_STATUS = "status";
    public static final String COLUMN_ORG_ID = "org_id";
    public static final String COLUMN_BRAND = "brand";
    public static final String COLUMN_CHANNEL = "channel";
    public static final String COLUMN_SOURCE_SYSTEM_ID = "source_system_id";
    public static final String COLUMN_EVENT_PAYLOAD = "event_payload";
    public static final String COLUMN_ERROR_CODE = "error_code";
    public static final String COLUMN_ERROR_MESSAGE = "error_message";
    public static final String COLUMN_PRODUCER_SERVICE = "producer_service";
    public static final String COLUMN_PRODUCER_EVENT_ID = "producer_event_id";
    public static final String COLUMN_RECEIVED_AT = "received_at";

    // ==================== Metadata Field Names ====================
    public static final String METADATA_SCAM_CHECK_SESSION_ID = "scamCheckSessionId";
    public static final String METADATA_IDEMPOTENCY_KEY = "idempotencyKey";
    public static final String METADATA_ORG_ID = "orgId";
    public static final String METADATA_BRAND = "brand";
    public static final String METADATA_CHANNEL = "channel";
    public static final String METADATA_SOURCE_SYSTEM_ID = "sourceSystemId";

    // ==================== GCS Notification Fields ====================
    public static final String FIELD_TIME_CREATED = "timeCreated";
    public static final String FIELD_METADATA = "metadata";
    public static final String FIELD_KMS_KEY_NAME = "kmsKeyName";

    // ==================== Validation Messages ====================
    public static final String VALIDATION_MSG_MISSING_METADATA = "Missing metadata section in message";
    public static final String VALIDATION_MSG_MISSING_SESSION_ID = "Missing scamCheckSessionId in metadata";
    public static final String VALIDATION_MSG_MISSING_IDEMPOTENCY_KEY = "Missing idempotencyKey in metadata";
    public static final String VALIDATION_MSG_MISSING_ORG_ID = "Missing orgId in metadata";
    public static final String VALIDATION_MSG_MISSING_BRAND = "Missing brand in metadata";
    public static final String VALIDATION_MSG_MISSING_CHANNEL = "Missing channel in metadata";
    public static final String VALIDATION_MSG_MISSING_TIME_CREATED = "Missing timeCreated field";
    public static final String VALIDATION_MSG_INVALID_UUID = "Invalid UUID format";
    public static final String VALIDATION_MSG_INVALID_TIMESTAMP = "Invalid timestamp format";

    // ==================== Error Codes ====================
    public static final String ERROR_CODE_VALIDATION_FAILED = "VALIDATION_FAILED";
    public static final String ERROR_CODE_DUPLICATE_MESSAGE = "DUPLICATE_MESSAGE";
    public static final String ERROR_CODE_SPANNER_WRITE_FAILED = "SPANNER_WRITE_FAILED";
    public static final String ERROR_CODE_TRANSFORMATION_FAILED = "TRANSFORMATION_FAILED";
    public static final String ERROR_CODE_DLQ_PUBLISH_FAILED = "DLQ_PUBLISH_FAILED";
    public static final String ERROR_CODE_UNKNOWN = "UNKNOWN_ERROR";

    // ==================== Logging Markers ====================
    public static final String LOG_MARKER_MESSAGE_RECEIVED = "MESSAGE_RECEIVED";
    public static final String LOG_MARKER_MESSAGE_VALIDATED = "MESSAGE_VALIDATED";
    public static final String LOG_MARKER_DUPLICATE_DETECTED = "DUPLICATE_DETECTED";
    public static final String LOG_MARKER_EVENT_CREATED = "EVENT_CREATED";
    public static final String LOG_MARKER_SPANNER_WRITE_SUCCESS = "SPANNER_WRITE_SUCCESS";
    public static final String LOG_MARKER_SPANNER_WRITE_FAILED = "SPANNER_WRITE_FAILED";
    public static final String LOG_MARKER_DLQ_PUBLISHED = "DLQ_PUBLISHED";
    public static final String LOG_MARKER_MESSAGE_ACKED = "MESSAGE_ACKED";
    public static final String LOG_MARKER_MESSAGE_NACKED = "MESSAGE_NACKED";
}
