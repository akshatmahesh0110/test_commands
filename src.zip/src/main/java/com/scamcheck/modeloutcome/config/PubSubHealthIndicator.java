package com.scamcheck.modeloutcome.config;

import com.scamcheck.modeloutcome.subscriber.ModelOutcomeSubscriber;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

/**
 * Custom health indicator for Pub/Sub subscriber.
 * Exposed via /actuator/health endpoint.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
@Component
@RequiredArgsConstructor
public class PubSubHealthIndicator implements HealthIndicator {

    private final ModelOutcomeSubscriber subscriber;

    @Override
    public Health health() {
        boolean healthy = subscriber.isSubscriberHealthy();

        if (healthy) {
            return Health.up()
                    .withDetail("subscriber", "Running")
                    .withDetail("status", "Listening for messages")
                    .build();
        } else {
            return Health.down()
                    .withDetail("subscriber", "Not running")
                    .withDetail("status", "Subscriber stopped or failed")
                    .build();
        }
    }
}