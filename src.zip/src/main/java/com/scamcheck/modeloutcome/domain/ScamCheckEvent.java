package com.scamcheck.modeloutcome.domain;

import com.google.cloud.spring.data.spanner.core.mapping.Column;
import com.google.cloud.spring.data.spanner.core.mapping.PrimaryKey;
import com.google.cloud.spring.data.spanner.core.mapping.Table;
import com.scamcheck.modeloutcome.config.ApplicationConstants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * Domain entity representing a scam check event in Spanner.
 * Maps to the scam_check_events_v1 table with composite primary key.
 *
 * Primary Key: (scam_check_session_id, version)
 * This ensures ordered append per session and distributes load across sessions.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
@Table(name = "scam_check_events_v1")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScamCheckEvent {

    /**
     * Globally unique event identifier (UUID format).
     * Not part of the primary key.
     */
    @Column(name = ApplicationConstants.COLUMN_EVENT_ID)
    private String eventId;

    /**
     * Aggregate root ID - stable across the session lifecycle.
     * Part of composite primary key for session-level correlation.
     */
    @PrimaryKey(keyOrder = 1)
    @Column(name = ApplicationConstants.COLUMN_SCAM_CHECK_SESSION_ID)
    private String scamCheckSessionId;

    /**
     * Monotonic version per scam_check_session_id.
     * Part of composite primary key - fixed to 3 for CALL_MODEL events.
     */
    @PrimaryKey(keyOrder = 2)
    @Column(name = ApplicationConstants.COLUMN_VERSION)
    private Long version;

    /**
     * Domain event time (when the business action occurred).
     * Extracted from timeCreated field of GCS notification.
     */
    @Column(name = ApplicationConstants.COLUMN_EVENT_TIMESTAMP)
    private Instant eventTimestamp;

    /**
     * Event schema version for upcasting/replayers.
     * Defaults to 1 for backward compatibility.
     */
    @Column(name = ApplicationConstants.COLUMN_EVENT_VERSION)
    private Long eventVersion;

    /**
     * Domain event type - fixed to "CALL_MODEL" for this microservice.
     */
    @Column(name = ApplicationConstants.COLUMN_EVENT_TYPE)
    private String eventType;

    /**
     * Lifecycle status for the event's effect.
     * Values: "IN-PROGRESS", "FAILED"
     */
    @Column(name = ApplicationConstants.COLUMN_STATUS)
    private String status;

    /**
     * Organisation identifier for multi-tenant filtering/routing.
     * Extracted from metadata.orgId
     */
    @Column(name = ApplicationConstants.COLUMN_ORG_ID)
    private String orgId;

    /**
     * Brand identifier to segment behaviour/reporting.
     * Extracted from metadata.brand
     */
    @Column(name = ApplicationConstants.COLUMN_BRAND)
    private String brand;

    /**
     * Channel identifier (e.g., MOBILE, WEB).
     * Extracted from metadata.channel
     */
    @Column(name = ApplicationConstants.COLUMN_CHANNEL)
    private String channel;

    /**
     * Source system identifier (optional).
     * Extracted from metadata.sourceSystemId
     */
    @Column(name = ApplicationConstants.COLUMN_SOURCE_SYSTEM_ID)
    private String sourceSystemId;

    /**
     * Flexible generic event payload in JSON format.
     * Contains complete GCS notification minus kmsKeyName.
     */
    @Column(name = ApplicationConstants.COLUMN_EVENT_PAYLOAD)
    private String eventPayload;

    /**
     * Compact error code for operational monitoring.
     * Populated for failed events.
     */
    @Column(name = ApplicationConstants.COLUMN_ERROR_CODE)
    private String errorCode;

    /**
     * Human-readable error message for failed/timeout events.
     */
    @Column(name = ApplicationConstants.COLUMN_ERROR_MESSAGE)
    private String errorMessage;

    /**
     * Name of producing microservice for observability.
     * Set to this microservice's name.
     */
    @Column(name = ApplicationConstants.COLUMN_PRODUCER_SERVICE)
    private String producerService;

    /**
     * Idempotency token from producer (unique within producer_service).
     * Extracted from metadata.idempotencyKey
     */
    @Column(name = ApplicationConstants.COLUMN_PRODUCER_EVENT_ID)
    private String producerEventId;

    /**
     * Ingestion time into Spanner.
     * Uses commit timestamp for traceability/ordering.
     * Automatically populated by Spanner.
     */
    @Column(name = ApplicationConstants.COLUMN_RECEIVED_AT)
    private Instant receivedAt;
}
