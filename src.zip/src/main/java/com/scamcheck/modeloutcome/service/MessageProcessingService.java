package com.scamcheck.modeloutcome.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scamcheck.modeloutcome.config.ApplicationConstants;
import com.scamcheck.modeloutcome.dto.GcsNotificationMessage;
import com.scamcheck.modeloutcome.domain.ScamCheckEvent;
import com.scamcheck.modeloutcome.exception.DuplicateMessageException;
import com.scamcheck.modeloutcome.exception.GlobalExceptionHandler;
import com.scamcheck.modeloutcome.exception.MessageProcessingException;
import com.scamcheck.modeloutcome.repository.ScamCheckEventRepository;
import com.scamcheck.modeloutcome.validator.MessageValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class MessageProcessingService {

    private final MessageValidator messageValidator;
    private final EventTransformerService eventTransformerService;
    private final DeadLetterPublisher deadLetterPublisher;
    private final GlobalExceptionHandler exceptionHandler;
    private final ObjectMapper objectMapper;

    // Make repository optional
    @Autowired(required = false)
    private ScamCheckEventRepository eventRepository;

    @Transactional
    public void processMessage(String messagePayload, String correlationId) {
        MDC.put("correlationId", correlationId);

        try {
            log.info("{} - Received message [correlationId={}]",
                    ApplicationConstants.LOG_MARKER_MESSAGE_RECEIVED, correlationId);

            // Step 1: Deserialize message
            GcsNotificationMessage message = deserializeMessage(messagePayload);

            // Step 2: Validate message
            messageValidator.validate(message);

            // Step 3: Extract key fields
            String sessionId = message.getMetadata().get(ApplicationConstants.METADATA_SCAM_CHECK_SESSION_ID);
            String producerEventId = message.getMetadata().get(ApplicationConstants.METADATA_IDEMPOTENCY_KEY);

            // Step 4: Check for duplicates
            checkForDuplicates(sessionId, producerEventId);

            // Step 5: Transform to domain event
            ScamCheckEvent event = eventTransformerService.transform(message);

            // Step 6: Persist to Spanner
            persistEvent(event);

            log.info("{} - Message processed successfully [sessionId={}, eventId={}]",
                    ApplicationConstants.LOG_MARKER_SPANNER_WRITE_SUCCESS,
                    sessionId, event.getEventId());

        } catch (DuplicateMessageException e) {
            log.info("{} - Duplicate message ignored [message={}]",
                    ApplicationConstants.LOG_MARKER_DUPLICATE_DETECTED, e.getMessage());

        } catch (Exception e) {
            log.error("Message processing failed [correlationId={}]", correlationId, e);
            throw e;

        } finally {
            MDC.remove("correlationId");
        }
    }

    private GcsNotificationMessage deserializeMessage(String messagePayload) {
        try {
            return objectMapper.readValue(messagePayload, GcsNotificationMessage.class);
        } catch (Exception e) {
            log.error("Failed to deserialize message", e);
            throw new MessageProcessingException(
                    ApplicationConstants.ERROR_CODE_TRANSFORMATION_FAILED,
                    "Failed to deserialize message: " + e.getMessage(),
                    e,
                    false
            );
        }
    }

    private void checkForDuplicates(String sessionId, String producerEventId) {
        boolean exists = eventRepository.findBySessionIdAndProducerEventId(sessionId, producerEventId)
                .isPresent();

        if (exists) {
            throw new DuplicateMessageException(sessionId, producerEventId);
        }
    }

    private void persistEvent(ScamCheckEvent event) {
        try {
            eventRepository.save(event);
            log.debug("Event persisted to Spanner [eventId={}, sessionId={}]",
                    event.getEventId(), event.getScamCheckSessionId());

        } catch (Exception e) {
            log.error("{} - Failed to write to Spanner [eventId={}, sessionId={}]",
                    ApplicationConstants.LOG_MARKER_SPANNER_WRITE_FAILED,
                    event.getEventId(), event.getScamCheckSessionId(), e);

            throw new MessageProcessingException(
                    ApplicationConstants.ERROR_CODE_SPANNER_WRITE_FAILED,
                    "Failed to write event to Spanner: " + e.getMessage(),
                    e,
                    true
            );
        }
    }

    public void handleFailedMessage(String messagePayload, Exception exception, String correlationId) {
        MDC.put("correlationId", correlationId);

        try {
            log.error("Handling failed message [correlationId={}]", correlationId, exception);

            GcsNotificationMessage message = deserializeMessage(messagePayload);
            String errorCode = exceptionHandler.getErrorCode(exception);

            ScamCheckEvent failedEvent = eventTransformerService.createFailedEvent(
                    message, exception, errorCode);

            try {
                eventRepository.save(failedEvent);
                log.info("Failed event written to Spanner [eventId={}]", failedEvent.getEventId());
            } catch (Exception spannerEx) {
                log.error("Could not write failed event to Spanner [eventId={}]",
                        failedEvent.getEventId(), spannerEx);
            }

            // Publish to DLQ
            deadLetterPublisher.publishToDeadLetter(failedEvent);

        } catch (Exception e) {
            log.error("Failed to handle failed message [correlationId={}]", correlationId, e);
        } finally {
            MDC.remove("correlationId");
        }
    }
}