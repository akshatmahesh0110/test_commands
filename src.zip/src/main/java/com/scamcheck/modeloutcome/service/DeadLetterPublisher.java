package com.scamcheck.modeloutcome.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.cloud.spring.pubsub.core.PubSubTemplate;
import com.scamcheck.modeloutcome.config.ApplicationConstants;
import com.scamcheck.modeloutcome.domain.ScamCheckEvent;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/**
 * Service for publishing failed messages to Dead Letter Queue (DLQ).
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
@Slf4j
@Service
public class DeadLetterPublisher {

    private final PubSubTemplate pubSubTemplate;
    private final ObjectMapper objectMapper;
    private final Counter dlqPublishSuccessCounter;
    private final Counter dlqPublishFailureCounter;

    @Value("${app.pubsub.dead-letter-topic}")
    private String deadLetterTopic;

    public DeadLetterPublisher(PubSubTemplate pubSubTemplate,
                               ObjectMapper objectMapper,
                               MeterRegistry meterRegistry) {
        this.pubSubTemplate = pubSubTemplate;
        this.objectMapper = objectMapper;

        this.dlqPublishSuccessCounter = Counter.builder("dlq.publish.success")
                .description("Total successful DLQ publishes")
                .register(meterRegistry);

        this.dlqPublishFailureCounter = Counter.builder("dlq.publish.failure")
                .description("Total failed DLQ publishes")
                .register(meterRegistry);
    }

    /**
     * Publish failed event to DLQ topic asynchronously.
     */
    public void publishToDeadLetter(ScamCheckEvent failedEvent) {
        try {
            String payload = objectMapper.writeValueAsString(failedEvent);

            CompletableFuture<String> future = pubSubTemplate.publish(deadLetterTopic, payload);

            future.orTimeout(5, TimeUnit.SECONDS)
                    .whenComplete((messageId, throwable) -> {
                        if (throwable != null) {
                            log.error("Failed to publish to DLQ [topic={}, eventId={}, error={}]",
                                    deadLetterTopic, failedEvent.getEventId(),
                                    throwable.getMessage(), throwable);
                            dlqPublishFailureCounter.increment();
                        } else {
                            log.info("{} - Published to DLQ [topic={}, eventId={}, messageId={}]",
                                    ApplicationConstants.LOG_MARKER_DLQ_PUBLISHED,
                                    deadLetterTopic, failedEvent.getEventId(), messageId);
                            dlqPublishSuccessCounter.increment();
                        }
                    });

        } catch (Exception e) {
            log.error("Exception while publishing to DLQ [topic={}, eventId={}]",
                    deadLetterTopic, failedEvent.getEventId(), e);
            dlqPublishFailureCounter.increment();
        }
    }
}