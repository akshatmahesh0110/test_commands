package com.scamcheck.modeloutcome.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scamcheck.modeloutcome.config.ApplicationConstants;
import com.scamcheck.modeloutcome.domain.ScamCheckEvent;
import com.scamcheck.modeloutcome.dto.EventPayload;
import com.scamcheck.modeloutcome.dto.GcsNotificationMessage;
import com.scamcheck.modeloutcome.exception.MessageProcessingException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

/**
 * Service for transforming GCS notification messages into ScamCheckEvent domain objects.
 * Handles data extraction, mapping, and JSON serialization.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class EventTransformerService {

    private final ObjectMapper objectMapper;

    @Value("${app.producer.service-name}")
    private String producerServiceName;

    @Value("${app.event.event-type}")
    private String eventType;

    @Value("${app.event.status}")
    private String status;

    @Value("${app.event.version}")
    private Long version;

    @Value("${app.event.event-version}")
    private Long eventVersion;

    /**
     * Transform GCS notification message to ScamCheckEvent domain object.
     *
     * @param message the GCS notification message
     * @return ScamCheckEvent ready for Spanner persistence
     */
    public ScamCheckEvent transform(GcsNotificationMessage message) {
        try {
            log.debug("Transforming message to ScamCheckEvent [sessionId={}]",
                    extractScamCheckSessionId(message));

            ScamCheckEvent event = ScamCheckEvent.builder()
                    .eventId(UUID.randomUUID().toString())
                    .scamCheckSessionId(extractScamCheckSessionId(message))
                    .version(version)
                    .eventTimestamp(Instant.parse(message.getTimeCreated()))
                    .eventVersion(eventVersion)
                    .eventType(eventType)
                    .status(status)
                    .orgId(extractOrgId(message))
                    .brand(extractBrand(message))
                    .channel(extractChannel(message))
                    .sourceSystemId(extractSourceSystemId(message))
                    .eventPayload(createEventPayload(message))
                    .producerService(producerServiceName)
                    .producerEventId(extractProducerEventId(message))
                    .build();

            log.debug("{} - Event transformed successfully [eventId={}, sessionId={}]",
                    ApplicationConstants.LOG_MARKER_EVENT_CREATED,
                    event.getEventId(),
                    event.getScamCheckSessionId());

            return event;

        } catch (Exception e) {
            log.error("Failed to transform message", e);
            throw new MessageProcessingException(
                    ApplicationConstants.ERROR_CODE_TRANSFORMATION_FAILED,
                    "Failed to transform message: " + e.getMessage(),
                    e,
                    false
            );
        }
    }

    /**
     * Create event payload JSON excluding kmsKeyName.
     *
     * @param message the GCS notification message
     * @return JSON string of event payload
     */
    private String createEventPayload(GcsNotificationMessage message) {
        try {
            EventPayload payload = EventPayload.builder()
                    .kind(message.getKind())
                    .id(message.getId())
                    .selfLink(message.getSelfLink())
                    .name(message.getName())
                    .bucket(message.getBucket())
                    .generation(message.getGeneration())
                    .metageneration(message.getMetageneration())
                    .contentType(message.getContentType())
                    .timeCreated(message.getTimeCreated())
                    .updated(message.getUpdated())
                    .storageClass(message.getStorageClass())
                    .timeStorageClassUpdated(message.getTimeStorageClassUpdated())
                    .size(message.getSize())
                    .mediaLink(message.getMediaLink())
                    .cacheControl(message.getCacheControl())
                    .metadata(message.getMetadata())
                    .etag(message.getEtag())
                    // NOTE: kmsKeyName is intentionally excluded
                    .build();

            return objectMapper.writeValueAsString(payload);

        } catch (JsonProcessingException e) {
            log.error("Failed to serialize event payload", e);
            throw new MessageProcessingException(
                    ApplicationConstants.ERROR_CODE_TRANSFORMATION_FAILED,
                    "Failed to serialize event payload",
                    e,
                    false
            );
        }
    }

    /**
     * Create failed event for DLQ and Spanner error recording.
     *
     * @param message the original message
     * @param exception the exception that caused failure
     * @param errorCode the error code
     * @return ScamCheckEvent with FAILED status
     */
    public ScamCheckEvent createFailedEvent(GcsNotificationMessage message, Exception exception, String errorCode) {
        try {
            return ScamCheckEvent.builder()
                    .eventId(UUID.randomUUID().toString())
                    .scamCheckSessionId(extractScamCheckSessionId(message))
                    .version(version)
                    .eventTimestamp(Instant.parse(message.getTimeCreated()))
                    .eventVersion(eventVersion)
                    .eventType(eventType)
                    .status(ApplicationConstants.EVENT_STATUS_FAILED)
                    .orgId(extractOrgId(message))
                    .brand(extractBrand(message))
                    .channel(extractChannel(message))
                    .sourceSystemId(extractSourceSystemId(message))
                    .eventPayload(createEventPayload(message))
                    .errorCode(errorCode)
                    .errorMessage(truncateErrorMessage(exception.getMessage()))
                    .producerService(producerServiceName)
                    .producerEventId(extractProducerEventId(message))
                    .build();
        } catch (Exception e) {
            log.error("Failed to create failed event, returning minimal event", e);
            // Return minimal event if transformation fails
            return ScamCheckEvent.builder()
                    .eventId(UUID.randomUUID().toString())
                    .scamCheckSessionId("UNKNOWN")
                    .version(version)
                    .eventTimestamp(Instant.now())
                    .eventVersion(eventVersion)
                    .eventType(eventType)
                    .status(ApplicationConstants.EVENT_STATUS_FAILED)
                    .errorCode(errorCode)
                    .errorMessage(truncateErrorMessage(exception.getMessage()))
                    .producerService(producerServiceName)
                    .producerEventId("UNKNOWN")
                    .build();
        }
    }

    // ==================== Field Extraction Methods ====================

    private String extractScamCheckSessionId(GcsNotificationMessage message) {
        return message.getMetadata().get(ApplicationConstants.METADATA_SCAM_CHECK_SESSION_ID);
    }

    private String extractProducerEventId(GcsNotificationMessage message) {
        return message.getMetadata().get(ApplicationConstants.METADATA_IDEMPOTENCY_KEY);
    }

    private String extractOrgId(GcsNotificationMessage message) {
        return message.getMetadata().get(ApplicationConstants.METADATA_ORG_ID);
    }

    private String extractBrand(GcsNotificationMessage message) {
        return message.getMetadata().get(ApplicationConstants.METADATA_BRAND);
    }

    private String extractChannel(GcsNotificationMessage message) {
        return message.getMetadata().get(ApplicationConstants.METADATA_CHANNEL);
    }

    private String extractSourceSystemId(GcsNotificationMessage message) {
        return message.getMetadata().getOrDefault(ApplicationConstants.METADATA_SOURCE_SYSTEM_ID, null);
    }

    /**
     * Truncate error message to fit Spanner column limits.
     *
     * @param message the error message
     * @return truncated message
     */
    private String truncateErrorMessage(String message) {
        if (message == null) {
            return null;
        }
        final int MAX_LENGTH = 5000; // Reasonable limit for error messages
        return message.length() > MAX_LENGTH ? message.substring(0, MAX_LENGTH) : message;
    }
}