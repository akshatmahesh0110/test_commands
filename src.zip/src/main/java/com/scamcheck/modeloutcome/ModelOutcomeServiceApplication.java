package com.scamcheck.modeloutcome;

import com.google.cloud.spring.data.spanner.repository.config.EnableSpannerRepositories;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Main application class for Model Outcome Microservice.
 *
 * Event-driven microservice for processing GCS notification events
 * from Pub/Sub and persisting to Cloud Spanner.
 *
 * Architecture:
 * - Continuous Pub/Sub pull subscriber using StreamingPull API
 * - Event-driven choreography pattern
 * - Native Spring Data Spanner persistence
 * - Idempotent message processing
 * - DLQ for failed messages
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
@Slf4j
@SpringBootApplication
@EnableTransactionManagement
public class ModelOutcomeServiceApplication {

    public static void main(String[] args) {
        log.info("Starting Model Outcome Microservice...");
        SpringApplication.run(ModelOutcomeServiceApplication.class, args);
        log.info("Model Outcome Microservice started successfully");
    }
}
