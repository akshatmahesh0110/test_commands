package com.scamcheck.modeloutcome.exception;

import com.scamcheck.modeloutcome.config.ApplicationConstants;

/**
 * Exception thrown when message validation fails.
 * Non-retryable as validation errors are permanent.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
public class ValidationException extends MessageProcessingException {

    public ValidationException(String message) {
        super(ApplicationConstants.ERROR_CODE_VALIDATION_FAILED, message, false);
    }

    public ValidationException(String message, Throwable cause) {
        super(ApplicationConstants.ERROR_CODE_VALIDATION_FAILED, message, cause, false);
    }
}