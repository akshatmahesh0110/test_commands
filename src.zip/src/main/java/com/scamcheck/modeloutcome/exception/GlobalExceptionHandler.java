package com.scamcheck.modeloutcome.exception;

import com.scamcheck.modeloutcome.config.ApplicationConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Global exception handler for message processing.
 * Centralizes exception handling logic following SOLID principles.
 *
 * Does NOT use @RestControllerAdvice as this is a non-REST service.
 * Exception handling is done at the subscriber level.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
@Slf4j
@Component
public class GlobalExceptionHandler {

    /**
     * Determine if an exception is retryable.
     *
     * @param exception the exception to evaluate
     * @return true if the exception warrants a retry
     */
    public boolean isRetryable(Exception exception) {
        if (exception instanceof MessageProcessingException mpe) {
            return mpe.isRetryable();
        }

        // Transient errors (network, timeout, etc.) are retryable
        return isTransientError(exception);
    }

    /**
     * Get error code from exception.
     *
     * @param exception the exception
     * @return error code string
     */
    public String getErrorCode(Exception exception) {
        if (exception instanceof MessageProcessingException mpe) {
            return mpe.getErrorCode();
        }
        return ApplicationConstants.ERROR_CODE_UNKNOWN;
    }

    /**
     * Check if error is transient (network, timeout, resource unavailable).
     *
     * @param exception the exception to evaluate
     * @return true if transient
     */
    private boolean isTransientError(Exception exception) {
        if (exception == null) {
            return false;
        }

        String exceptionClass = exception.getClass().getName();
        String message = exception.getMessage() != null ? exception.getMessage().toLowerCase() : "";

        // Check for transient error indicators
        return exceptionClass.contains("Timeout") ||
                exceptionClass.contains("Connection") ||
                exceptionClass.contains("Unavailable") ||
                message.contains("timeout") ||
                message.contains("connection") ||
                message.contains("unavailable") ||
                message.contains("deadline exceeded");
    }

    /**
     * Log exception with appropriate context.
     *
     * @param exception the exception to log
     * @param sessionId the scam check session ID for correlation
     */
    public void logException(Exception exception, String sessionId) {
        String errorCode = getErrorCode(exception);
        boolean retryable = isRetryable(exception);

        if (retryable) {
            log.warn("Retryable error occurred [errorCode={}, sessionId={}, message={}]",
                    errorCode, sessionId, exception.getMessage(), exception);
        } else {
            log.error("Non-retryable error occurred [errorCode={}, sessionId={}, message={}]",
                    errorCode, sessionId, exception.getMessage(), exception);
        }
    }
}