package com.scamcheck.modeloutcome.exception;

import com.scamcheck.modeloutcome.config.ApplicationConstants;

/**
 * Exception thrown when duplicate message is detected.
 * Non-retryable as duplicate should be silently ignored.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
public class DuplicateMessageException extends MessageProcessingException {

    public DuplicateMessageException(String scamCheckSessionId, String producerEventId) {
        super(
                ApplicationConstants.ERROR_CODE_DUPLICATE_MESSAGE,
                String.format("Duplicate message detected for sessionId=%s, producerEventId=%s",
                        scamCheckSessionId, producerEventId),
                false
        );
    }
}