package com.scamcheck.modeloutcome.exception;

import lombok.Getter;

/**
 * Base exception for message processing errors.
 * Extends RuntimeException for unchecked exception handling.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
@Getter
public class MessageProcessingException extends RuntimeException {

    private final String errorCode;
    private final boolean retryable;

    public MessageProcessingException(String errorCode, String message, boolean retryable) {
        super(message);
        this.errorCode = errorCode;
        this.retryable = retryable;
    }

    public MessageProcessingException(String errorCode, String message, Throwable cause, boolean retryable) {
        super(message, cause);
        this.errorCode = errorCode;
        this.retryable = retryable;
    }
}