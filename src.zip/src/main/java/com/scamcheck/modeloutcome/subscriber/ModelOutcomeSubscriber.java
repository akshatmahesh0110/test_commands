package com.scamcheck.modeloutcome.subscriber;

import com.google.cloud.spring.pubsub.core.PubSubTemplate;
import com.google.cloud.spring.pubsub.support.BasicAcknowledgeablePubsubMessage;
import com.google.pubsub.v1.PubsubMessage;
import com.scamcheck.modeloutcome.config.ApplicationConstants;
import com.scamcheck.modeloutcome.exception.DuplicateMessageException;
import com.scamcheck.modeloutcome.exception.GlobalExceptionHandler;
import com.scamcheck.modeloutcome.service.MessageProcessingService;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * Continuous Pub/Sub subscriber using PubSubTemplate.subscribe() method.
 * Uses StreamingPull API internally for high throughput and low latency.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
@Slf4j
@Component
public class ModelOutcomeSubscriber {

    private final PubSubTemplate pubSubTemplate;
    private final MessageProcessingService messageProcessingService;
    private final GlobalExceptionHandler exceptionHandler;
    private com.google.cloud.pubsub.v1.Subscriber subscriber;

    private final Counter messagesReceivedCounter;
    private final Counter messagesProcessedCounter;
    private final Counter messagesFailedCounter;
    private final Counter messagesDuplicateCounter;
    private final Counter messagesRetriedCounter;
    private final Timer processingTimer;

    @Value("${app.pubsub.subscription-name}")
    private String subscriptionName;

    @Value("${app.pubsub.max-retry-attempts}")
    private int maxRetryAttempts;

    private volatile boolean isRunning = false;

    public ModelOutcomeSubscriber(PubSubTemplate pubSubTemplate,
                                  MessageProcessingService messageProcessingService,
                                  GlobalExceptionHandler exceptionHandler,
                                  MeterRegistry meterRegistry) {
        this.pubSubTemplate = pubSubTemplate;
        this.messageProcessingService = messageProcessingService;
        this.exceptionHandler = exceptionHandler;

        // Initialize metrics
        this.messagesReceivedCounter = Counter.builder("pubsub.messages.received")
                .description("Total messages received from Pub/Sub")
                .register(meterRegistry);

        this.messagesProcessedCounter = Counter.builder("pubsub.messages.processed")
                .description("Total messages successfully processed")
                .register(meterRegistry);

        this.messagesFailedCounter = Counter.builder("pubsub.messages.failed")
                .description("Total messages failed after max retries")
                .register(meterRegistry);

        this.messagesDuplicateCounter = Counter.builder("pubsub.messages.duplicate")
                .description("Total duplicate messages detected")
                .register(meterRegistry);

        this.messagesRetriedCounter = Counter.builder("pubsub.messages.retried")
                .description("Total messages retried")
                .register(meterRegistry);

        this.processingTimer = Timer.builder("pubsub.processing.duration")
                .description("Message processing duration")
                .register(meterRegistry);
    }

    /**
     * Start the Pub/Sub subscriber after bean initialization.
     */
    @PostConstruct
    public void startSubscriber() {
        log.info("Starting Pub/Sub subscriber for subscription: {}", subscriptionName);

        try {
            subscriber = pubSubTemplate.subscribe(subscriptionName, this::handleMessage);
            isRunning = true;

            log.info("✓ Pub/Sub subscriber started successfully for subscription: {}", subscriptionName);
            log.info("✓ Application is now listening for messages continuously...");

        } catch (Exception e) {
            log.error("✗ Failed to start Pub/Sub subscriber for subscription: {}", subscriptionName, e);
            throw new IllegalStateException("Failed to start Pub/Sub subscriber", e);
        }
    }

    /**
     * Message handler for incoming Pub/Sub messages.
     */
    private void handleMessage(BasicAcknowledgeablePubsubMessage message) {
        if (!isRunning) {
            log.warn("Subscriber is not running, nacking message");
            message.nack();
            return;
        }

        messagesReceivedCounter.increment();

        //TODO: Replace with Id from message
        String correlationId = UUID.randomUUID().toString();
        String payload = null;

        Timer.Sample sample = Timer.start();

        try {
            payload = message.getPubsubMessage().getData().toStringUtf8();

            //TODO: Temporary log applied
            log.info("Message received_1:{}", payload);

            PubsubMessage pubsubMessage = message.getPubsubMessage();
            int deliveryAttempt = getDeliveryAttempt(pubsubMessage);

            log.info("{} - Processing message [correlationId={}, deliveryAttempt={}/{}]",
                    ApplicationConstants.LOG_MARKER_MESSAGE_RECEIVED,
                    correlationId, deliveryAttempt, maxRetryAttempts);

            // Process message
            messageProcessingService.processMessage(payload, correlationId);

            // Success - acknowledge
            message.ack();
            messagesProcessedCounter.increment();

            log.info("{} - Message acknowledged [correlationId={}]",
                    ApplicationConstants.LOG_MARKER_MESSAGE_ACKED, correlationId);

        } catch (DuplicateMessageException e) {
            // Special handling for duplicates - always ACK
            log.info("{} - Duplicate message detected, acknowledging [correlationId={}]",
                    ApplicationConstants.LOG_MARKER_DUPLICATE_DETECTED, correlationId);
            messagesDuplicateCounter.increment();
            message.ack();

        } catch (Exception e) {
            handleProcessingException(payload, message, e, correlationId,
                    getDeliveryAttempt(message.getPubsubMessage()));

        } finally {
            sample.stop(processingTimer);
        }
    }

    /**
     * Handle processing exception with retry logic.
     */
    private void handleProcessingException(String payload,
                                           BasicAcknowledgeablePubsubMessage message,
                                           Exception exception,
                                           String correlationId,
                                           int deliveryAttempt) {

        exceptionHandler.logException(exception, correlationId);
        boolean isRetryable = exceptionHandler.isRetryable(exception);

        if (isRetryable && deliveryAttempt < maxRetryAttempts) {
            log.warn("Retryable error - NACK message for redelivery [correlationId={}, attempt={}/{}]",
                    correlationId, deliveryAttempt, maxRetryAttempts);

            message.nack();
            messagesRetriedCounter.increment();

            log.info("{} - Message nacked for retry [correlationId={}]",
                    ApplicationConstants.LOG_MARKER_MESSAGE_NACKED, correlationId);

        } else {
            String reason = isRetryable ? "Max retry attempts reached" : "Non-retryable error";
            log.error("Message processing failed permanently [correlationId={}, reason={}]",
                    correlationId, reason);

            // Handle failed message: write to Spanner + DLQ
            if (payload != null) {
                messageProcessingService.handleFailedMessage(payload, exception, correlationId);
            }

            // Acknowledge to remove from subscription
            message.ack();
            messagesFailedCounter.increment();

            log.info("{} - Failed message acknowledged after DLQ publish [correlationId={}]",
                    ApplicationConstants.LOG_MARKER_MESSAGE_ACKED, correlationId);
        }
    }

    /**
     * Extract delivery attempt from message attributes.
     */
    private int getDeliveryAttempt(PubsubMessage pubsubMessage) {
        try {
            String attemptStr = pubsubMessage.getAttributesOrDefault(
                    "googclient_deliveryattempt", "1");
            return Integer.parseInt(attemptStr);
        } catch (NumberFormatException e) {
            log.warn("Could not parse delivery attempt, defaulting to 1", e);
            return 1;
        }
    }

    /**
     * Health check method for actuator.
     */
    public boolean isSubscriberHealthy() {
        return isRunning && subscriber != null && subscriber.isRunning();
    }

    /**
     * Gracefully stop the subscriber on application shutdown.
     */
    @PreDestroy
    public void stopSubscriber() {
        if (subscriber != null && isRunning) {
            log.info("Stopping Pub/Sub subscriber for subscription: {}", subscriptionName);
            isRunning = false;

            try {
                subscriber.stopAsync().awaitTerminated(30, TimeUnit.SECONDS);
                log.info("✓ Pub/Sub subscriber stopped successfully");
            } catch (Exception e) {
                log.error("✗ Error stopping Pub/Sub subscriber", e);
            }
        }
    }
}