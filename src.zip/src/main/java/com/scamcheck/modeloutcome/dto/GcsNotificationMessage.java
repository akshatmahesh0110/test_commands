package com.scamcheck.modeloutcome.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * DTO representing a GCS notification message from Pub/Sub.
 * Maps to the Cloud Storage object notification format.
 *
 * Uses Jackson for JSON deserialization with validation annotations.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class GcsNotificationMessage {

    @JsonProperty("kind")
    private String kind;

    @JsonProperty("id")
    @NotBlank(message = "GCS object id must not be blank")
    private String id;

    @JsonProperty("selfLink")
    private String selfLink;

    @JsonProperty("name")
    @NotBlank(message = "Object name must not be blank")
    private String name;

    @JsonProperty("bucket")
    @NotBlank(message = "Bucket name must not be blank")
    private String bucket;

    @JsonProperty("generation")
    private String generation;

    @JsonProperty("metageneration")
    private String metageneration;

    @JsonProperty("contentType")
    private String contentType;

    @JsonProperty("timeCreated")
    @NotBlank(message = "timeCreated must not be blank")
    private String timeCreated;

    @JsonProperty("updated")
    private String updated;

    @JsonProperty("storageClass")
    private String storageClass;

    @JsonProperty("timeStorageClassUpdated")
    private String timeStorageClassUpdated;

    @JsonProperty("size")
    private String size;

    @JsonProperty("mediaLink")
    private String mediaLink;

    @JsonProperty("cacheControl")
    private String cacheControl;

    @JsonProperty("metadata")
    @NotNull(message = "Metadata section must not be null")
    private Map<String, String> metadata;

    @JsonProperty("etag")
    private String etag;

    /**
     * KMS Key Name - EXCLUDED from event_payload as per requirements.
     */
    @JsonProperty("kmsKeyName")
    private String kmsKeyName;
}