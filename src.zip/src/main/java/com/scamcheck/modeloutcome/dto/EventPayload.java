package com.scamcheck.modeloutcome.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * DTO for event payload stored in Spanner's event_payload JSON column.
 * Contains all GCS notification fields EXCEPT kmsKeyName.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EventPayload {

    @JsonProperty("kind")
    private String kind;

    @JsonProperty("id")
    private String id;

    @JsonProperty("selfLink")
    private String selfLink;

    @JsonProperty("name")
    private String name;

    @JsonProperty("bucket")
    private String bucket;

    @JsonProperty("generation")
    private String generation;

    @JsonProperty("metageneration")
    private String metageneration;

    @JsonProperty("contentType")
    private String contentType;

    @JsonProperty("timeCreated")
    private String timeCreated;

    @JsonProperty("updated")
    private String updated;

    @JsonProperty("storageClass")
    private String storageClass;

    @JsonProperty("timeStorageClassUpdated")
    private String timeStorageClassUpdated;

    @JsonProperty("size")
    private String size;

    @JsonProperty("mediaLink")
    private String mediaLink;

    @JsonProperty("cacheControl")
    private String cacheControl;

    @JsonProperty("metadata")
    private Map<String, String> metadata;

    @JsonProperty("etag")
    private String etag;

    // NOTE: kmsKeyName is intentionally excluded
}