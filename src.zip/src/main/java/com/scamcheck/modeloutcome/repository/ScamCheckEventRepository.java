package com.scamcheck.modeloutcome.repository;

import com.google.cloud.spanner.Key;
import com.google.cloud.spring.data.spanner.repository.SpannerRepository;
import com.google.cloud.spring.data.spanner.repository.query.Query;
import com.scamcheck.modeloutcome.domain.ScamCheckEvent;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Spring Data Spanner repository for ScamCheckEvent entity.
 *
 * CORRECTED: Uses Key type for composite primary key (scamCheckSessionId, version).
 * The Key type is required for Spanner tables with composite primary keys.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
@Repository
public interface ScamCheckEventRepository extends SpannerRepository<ScamCheckEvent, Key> {

    /**
     * Check for duplicate message based on session ID and producer event ID (idempotency key).
     * Used for idempotent message processing.
     *
     * @param scamCheckSessionId the scam check session ID
     * @param producerEventId the idempotency key from message metadata
     * @return Optional containing existing event if found
     */
    @Query("SELECT * FROM scam_check_events_v1 " +
            "WHERE scam_check_session_id = @sessionId " +
            "AND producer_event_id = @producerEventId " +
            "LIMIT 1")
    Optional<ScamCheckEvent> findBySessionIdAndProducerEventId(
            @Param("sessionId") String scamCheckSessionId,
            @Param("producerEventId") String producerEventId
    );
}