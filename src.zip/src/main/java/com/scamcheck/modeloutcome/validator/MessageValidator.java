package com.scamcheck.modeloutcome.validator;

import com.scamcheck.modeloutcome.config.ApplicationConstants;
import com.scamcheck.modeloutcome.dto.GcsNotificationMessage;
import com.scamcheck.modeloutcome.exception.ValidationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Comprehensive validator for GCS notification messages.
 * Validates message structure, required fields, and data formats.
 *
 * @author Scam Check Team
 * @version 1.0.0
 */
@Slf4j
@Component
public class MessageValidator {

    /**
     * Validate the complete GCS notification message.
     * Throws ValidationException if any validation fails.
     *
     * @param message the message to validate
     * @throws ValidationException if validation fails
     */
    public void validate(GcsNotificationMessage message) {
        log.debug("Starting validation for message: bucket={}, name={}",
                message.getBucket(), message.getName());

        List<String> errors = new ArrayList<>();

        // Validate metadata section exists
        if (message.getMetadata() == null || message.getMetadata().isEmpty()) {
            errors.add(ApplicationConstants.VALIDATION_MSG_MISSING_METADATA);
        } else {
            validateMetadata(message.getMetadata(), errors);
        }

        // Validate timeCreated
        validateTimeCreated(message.getTimeCreated(), errors);

        // Validate basic required fields
        if (StringUtils.isBlank(message.getBucket())) {
            errors.add("Bucket name must not be blank");
        }

        if (StringUtils.isBlank(message.getName())) {
            errors.add("Object name must not be blank");
        }

        // If validation errors exist, throw exception
        if (!errors.isEmpty()) {
            String errorMessage = "Message validation failed: " + String.join("; ", errors);
            log.error("Validation failed: {}", errorMessage);
            throw new ValidationException(errorMessage);
        }

        log.debug("{} - Message validation successful", ApplicationConstants.LOG_MARKER_MESSAGE_VALIDATED);
    }

    /**
     * Validate metadata section for required fields.
     *
     * @param metadata the metadata map
     * @param errors list to accumulate errors
     */
    private void validateMetadata(Map<String, String> metadata, List<String> errors) {
        validateRequiredMetadataField(metadata, ApplicationConstants.METADATA_SCAM_CHECK_SESSION_ID,
                ApplicationConstants.VALIDATION_MSG_MISSING_SESSION_ID, errors);

        validateRequiredMetadataField(metadata, ApplicationConstants.METADATA_IDEMPOTENCY_KEY,
                ApplicationConstants.VALIDATION_MSG_MISSING_IDEMPOTENCY_KEY, errors);

        validateRequiredMetadataField(metadata, ApplicationConstants.METADATA_ORG_ID,
                ApplicationConstants.VALIDATION_MSG_MISSING_ORG_ID, errors);

        validateRequiredMetadataField(metadata, ApplicationConstants.METADATA_BRAND,
                ApplicationConstants.VALIDATION_MSG_MISSING_BRAND, errors);

        validateRequiredMetadataField(metadata, ApplicationConstants.METADATA_CHANNEL,
                ApplicationConstants.VALIDATION_MSG_MISSING_CHANNEL, errors);

        // Validate UUID formats for session ID and idempotency key
        if (metadata.containsKey(ApplicationConstants.METADATA_SCAM_CHECK_SESSION_ID)) {
            validateUUID(metadata.get(ApplicationConstants.METADATA_SCAM_CHECK_SESSION_ID),
                    "scamCheckSessionId", errors);
        }

        if (metadata.containsKey(ApplicationConstants.METADATA_IDEMPOTENCY_KEY)) {
            validateUUID(metadata.get(ApplicationConstants.METADATA_IDEMPOTENCY_KEY),
                    "idempotencyKey", errors);
        }
    }

    /**
     * Validate a required metadata field exists and is not blank.
     *
     * @param metadata the metadata map
     * @param fieldName the field name to check
     * @param errorMessage the error message if validation fails
     * @param errors list to accumulate errors
     */
    private void validateRequiredMetadataField(Map<String, String> metadata, String fieldName,
                                               String errorMessage, List<String> errors) {
        if (!metadata.containsKey(fieldName) || StringUtils.isBlank(metadata.get(fieldName))) {
            errors.add(errorMessage);
        }
    }

    /**
     * Validate UUID format.
     *
     * @param value the value to validate
     * @param fieldName the field name for error messaging
     * @param errors list to accumulate errors
     */
    private void validateUUID(String value, String fieldName, List<String> errors) {
        if (StringUtils.isNotBlank(value)) {
            try {
                UUID.fromString(value);
            } catch (IllegalArgumentException e) {
                errors.add(String.format("%s - %s: %s",
                        ApplicationConstants.VALIDATION_MSG_INVALID_UUID, fieldName, value));
            }
        }
    }

    /**
     * Validate timeCreated timestamp format.
     *
     * @param timeCreated the timestamp string
     * @param errors list to accumulate errors
     */
    private void validateTimeCreated(String timeCreated, List<String> errors) {
        if (StringUtils.isBlank(timeCreated)) {
            errors.add(ApplicationConstants.VALIDATION_MSG_MISSING_TIME_CREATED);
            return;
        }

        try {
            Instant.parse(timeCreated);
        } catch (DateTimeParseException e) {
            errors.add(String.format("%s: %s",
                    ApplicationConstants.VALIDATION_MSG_INVALID_TIMESTAMP, timeCreated));
        }
    }
}