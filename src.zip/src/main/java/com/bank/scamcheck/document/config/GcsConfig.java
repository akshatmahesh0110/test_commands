package com.bank.scamcheck.document.config;

import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class GcsConfig {

    @Value("${gcs.project-id}")
    private String projectId;

    @Bean
    public Storage googleCloudStorage() {
        log.info("Initializing Google Cloud Storage with Application Default Credentials");
        log.info("Project ID: {}", projectId);

        // This automatically uses Application Default Credentials
        Storage storage = StorageOptions.newBuilder()
                .setProjectId(projectId)
                .build()
                .getService();

        log.info("✅ Google Cloud Storage client initialized successfully");
        return storage;
    }
}