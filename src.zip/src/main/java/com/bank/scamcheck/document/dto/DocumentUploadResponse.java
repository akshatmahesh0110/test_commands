package com.bank.scamcheck.document.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.time.LocalDateTime;

/**
 * Data Transfer Object for document upload response.
 * Provides comprehensive feedback about the document upload operation
 * including success status, metadata, and processing information.
 */
@Schema(description = "Document upload response with processing details")
public record DocumentUploadResponse(

        @Schema(description = "Upload operation success status", example = "true")
        boolean success,

        @Schema(description = "Scam check session identifier",
                example = "550e8400-e29b-41d4-a716-446655440000")
        String scamCheckSessionId,

        @Schema(description = "GCS bucket path where document is stored",
                example = "clean-image-gcs-bucket/550e8400-e29b-41d4-a716-446655440000/")
        String storagePath,

        @Schema(description = "Number of images processed", example = "4")
        int imageCount,

        @Schema(description = "Total file size in bytes", example = "25165824")
        long fileSizeBytes,

        @Schema(description = "NSFW check result", example = "false")
        boolean nsfwDetected,

        @Schema(description = "Processing timestamp", example = "2025-07-29T12:30:45")
        LocalDateTime processedAt,

        @Schema(description = "Processing time in milliseconds", example = "1250")
        long processingTimeMs,

        @Schema(description = "Response message", example = "Document uploaded successfully")
        String message
) {

    /**
     * Creates a successful upload response.
     *
     * @param scamCheckSessionId Session identifier
     * @param storagePath GCS storage path
     * @param imageCount Number of processed images
     * @param fileSizeBytes File size in bytes
     * @param nsfwDetected NSFW detection result
     * @param processingTimeMs Processing duration
     * @return Success response
     */
    public static DocumentUploadResponse success(String scamCheckSessionId,
                                                 String storagePath,
                                                 int imageCount,
                                                 long fileSizeBytes,
                                                 boolean nsfwDetected,
                                                 long processingTimeMs) {
        return new DocumentUploadResponse(
                true,
                scamCheckSessionId,
                storagePath,
                imageCount,
                fileSizeBytes,
                nsfwDetected,
                LocalDateTime.now(),
                processingTimeMs,
                "Document uploaded successfully"
        );
    }

    /**
     * Creates a failure upload response.
     *
     * @param scamCheckSessionId Session identifier
     * @param errorMessage Error description
     * @param processingTimeMs Processing duration
     * @return Failure response
     */
    public static DocumentUploadResponse failure(String scamCheckSessionId,
                                                 String errorMessage,
                                                 long processingTimeMs) {
        return new DocumentUploadResponse(
                false,
                scamCheckSessionId,
                null,
                0,
                0,
                false,
                LocalDateTime.now(),
                processingTimeMs,
                errorMessage
        );
    }
}