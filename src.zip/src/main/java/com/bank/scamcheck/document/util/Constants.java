package com.bank.scamcheck.document.util;

/**
 * Application-wide constants for the Scam Check Document Service.
 * Contains all static values used across the application including
 * header names, file constraints, and service configuration values.
 */
public final class Constants {

    // HTTP Headers
    public static final String HEADER_ABC_BRAND = "x-abc-brand";
    public static final String HEADER_ORG_ID = "x-org-id";
    public static final String HEADER_ABC_CHANNEL = "x-abc-channel";
    public static final String HEADER_SCAM_CHECK_SESSION_ID = "scam-check-session-id";

    // File Constraints
    public static final long MAX_FILE_SIZE = 30 * 1024 * 1024; // 30MB
    public static final int MAX_IMAGES_PER_ZIP = 4;
    public static final long AVERAGE_IMAGE_SIZE = 4 * 1024 * 1024; // 4MB

    // Supported File Types
    public static final String[] SUPPORTED_IMAGE_TYPES = {
            "image/jpeg", "image/jpg", "image/png", "image/gif", "image/bmp"
    };

    // Error Messages
    public static final String ERROR_FILE_TOO_LARGE = "File size exceeds maximum allowed limit of 30MB";
    public static final String ERROR_INVALID_FILE_TYPE = "Invalid file type. Only ZIP files are supported";
    public static final String ERROR_NSFW_CONTENT_DETECTED = "NSFW content detected in uploaded images";
    public static final String ERROR_STORAGE_FAILURE = "Failed to store document in cloud storage";

    // === CHANGES FOR INITIALISATION START ===
    // Initialization Constants
    public static final String ERROR_INVALID_PAYEE_DETAILS = "Invalid payee details provided";
    public static final String ERROR_DUPLICATE_REFERENCE_ID = "Reference ID already exists";
    public static final String ERROR_INITIALIZATION_FAILED = "Failed to initialize scam check session";

    // API Paths
    public static final String BASE_PATH = "/economic-crime-prevention/resolving-fraud/scamcheck/v1";
    public static final String DOCUMENTS_PATH = BASE_PATH + "/documents";
    public static final String INITIALISATION_PATH = BASE_PATH + "/initialisation";

    // System IDs
    public static final String[] SUPPORTED_SYSTEM_IDS = {
            "PAYMENTS", "TRANSFERS", "STANDING_ORDERS", "DIRECT_DEBITS"
    };
    // === CHANGES FOR INITIALISATION END ===

    // Service Configuration
    public static final String GCS_BUCKET_NAME = "clean-image-gcs-bucket";
    public static final int ASYNC_POOL_CORE_SIZE = 10;
    public static final int ASYNC_POOL_MAX_SIZE = 50;
    public static final int ASYNC_POOL_QUEUE_CAPACITY = 1000;

    // Private constructor to prevent instantiation
    private Constants() {
        throw new UnsupportedOperationException("Constants class cannot be instantiated");
    }
}