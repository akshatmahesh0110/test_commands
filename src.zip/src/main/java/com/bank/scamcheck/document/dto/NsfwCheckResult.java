package com.bank.scamcheck.document.dto;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Data Transfer Object for NSFW check result.
 * Encapsulates the result of Not Safe For Work content detection
 * analysis performed on uploaded images.
 */
@Schema(description = "NSFW content detection result")
public record NsfwCheckResult(

        @Schema(description = "Whether NSFW content was detected", example = "false")
        boolean nsfwDetected,

        @Schema(description = "Confidence score of NSFW detection (0.0-1.0)", example = "0.12")
        double confidenceScore,

        @Schema(description = "Number of images analyzed", example = "4")
        int analyzedImageCount,

        @Schema(description = "Analysis duration in milliseconds", example = "850")
        long analysisTimeMs,

        @Schema(description = "Additional details about the analysis",
                example = "All images passed NSFW check")
        String details
) {

    /**
     * Creates a safe content result (no NSFW detected).
     *
     * @param analyzedImageCount Number of images analyzed
     * @param analysisTimeMs Analysis duration
     * @return Safe content result
     */
    public static NsfwCheckResult safe(int analyzedImageCount, long analysisTimeMs) {
        return new NsfwCheckResult(
                false,
                0.0,
                analyzedImageCount,
                analysisTimeMs,
                "All images passed NSFW check"
        );
    }

    /**
     * Creates an unsafe content result (NSFW detected).
     *
     * @param confidenceScore Confidence of detection
     * @param analyzedImageCount Number of images analyzed
     * @param analysisTimeMs Analysis duration
     * @return Unsafe content result
     */
    public static NsfwCheckResult unsafe(double confidenceScore,
                                         int analyzedImageCount,
                                         long analysisTimeMs) {
        return new NsfwCheckResult(
                true,
                confidenceScore,
                analyzedImageCount,
                analysisTimeMs,
                "NSFW content detected in one or more images"
        );
    }
}