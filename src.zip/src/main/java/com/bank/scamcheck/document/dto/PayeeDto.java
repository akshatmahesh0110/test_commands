package com.bank.scamcheck.document.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * Data Transfer Object for payee information in scam check initialization.
 *
 * Contains all necessary payee details required for scam verification
 * including banking details and personal information.
 */
@Schema(description = "Payee information for scam check initialization")
public record PayeeDto(

        @Schema(description = "Payee's bank sort code", example = "12-34-56", required = true)
        @NotBlank(message = "Sort code is required")
        @Pattern(regexp = "^\\d{2}-\\d{2}-\\d{2}$", message = "Sort code must be in format XX-XX-XX")
        String sortCode,

        @Schema(description = "Payee's account number", example = "12345678", required = true)
        @NotBlank(message = "Account number is required")
        @Pattern(regexp = "^\\d{8}$", message = "Account number must be 8 digits")
        String accountNumber,

        @Schema(description = "Payee's first name", example = "John", required = true)
        @NotBlank(message = "First name is required")
        String firstName,

        @Schema(description = "Payee's surname", example = "Doe", required = true)
        @NotBlank(message = "Surname is required")
        String surname,

        @Schema(description = "Payment amount", example = "1500.00", required = true)
        @NotNull(message = "Payment amount is required")
        @DecimalMin(value = "0.01", message = "Payment amount must be greater than 0")
        BigDecimal paymentAmount
) {
    /**
     * Creates a PayeeDto with validation and sanitization.
     */
    public PayeeDto {
        if (firstName != null) {
            firstName = firstName.trim();
        }
        if (surname != null) {
            surname = surname.trim();
        }
        if (sortCode != null) {
            sortCode = sortCode.trim();
        }
        if (accountNumber != null) {
            accountNumber = accountNumber.trim();
        }
    }
}
