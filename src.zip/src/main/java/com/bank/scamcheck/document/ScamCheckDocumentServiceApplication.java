package com.bank.scamcheck.document;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Main application class for Scam Check Document Upload Service.
 * This microservice handles document upload operations for scam check system,
 * providing secure, scalable, and efficient document processing capabilities.

 * @version 1.0.0
 */
@SpringBootApplication
@EnableAsync
public class ScamCheckDocumentServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ScamCheckDocumentServiceApplication.class, args);
    }
}
