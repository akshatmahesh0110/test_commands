package com.bank.scamcheck.document.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

/**
 * Data Transfer Object for document upload request.
 * Encapsulates all the necessary information required for processing
 * a document upload request in the scam check system.
 */
@Schema(description = "Document upload request containing metadata")
public record DocumentUploadRequest(

        @Schema(description = "Brand identifier for ABC bank", example = "ABC_RETAIL")
        String abcBrand,

        @Schema(description = "Organization or bank identifier", example = "ABC_BANK", required = true)
        @NotBlank(message = "Organization ID is required")
        String orgId,

        @Schema(description = "Channel identifier (Web/Mobile)", example = "WEB")
        String abcChannel,

        @Schema(description = "Unique scam check session identifier",
                example = "550e8400-e29b-41d4-a716-446655440000", required = true)
        @NotBlank(message = "Scam check session ID is required")
        @Pattern(regexp = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$",
                message = "Scam check session ID must be a valid UUID")
        String scamCheckSessionId
) {
    /**
     * Creates a DocumentUploadRequest with validation.
     *
     * @param abcBrand Brand identifier (optional)
     * @param orgId Organization identifier (required)
     * @param abcChannel Channel identifier (optional)
     * @param scamCheckSessionId Session ID (required, must be valid UUID)
     */
    public DocumentUploadRequest {
        // Compact constructor for validation
        if (orgId != null) {
            orgId = orgId.trim();
        }
        if (scamCheckSessionId != null) {
            scamCheckSessionId = scamCheckSessionId.trim();
        }
    }
}
