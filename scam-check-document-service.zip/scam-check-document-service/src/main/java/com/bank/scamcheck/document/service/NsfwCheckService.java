package com.bank.scamcheck.document.service;

import com.bank.scamcheck.document.dto.NsfwCheckResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Service for Not Safe For Work (NSFW) content detection.

 * This service provides content moderation capabilities for uploaded images,
 * ensuring that inappropriate content is detected and filtered before storage.

 * Current implementation provides a stub for the actual NSFW detection service
 * integration, which will be implemented when the external service is available.

 * @version 1.0.0
 */
@Service
@Slf4j
public class NsfwCheckService {

    /**
     * Performs NSFW content analysis on uploaded ZIP file containing images.

     * This method will integrate with an external NSFW detection service
     * to analyze each image in the uploaded ZIP file. Currently, returns
     * a safe result as a placeholder until the actual service is implemented.

     * @param file The ZIP file containing images to analyze
     * @return NsfwCheckResult with detection results
     */
    public NsfwCheckResult checkNsfwContent(MultipartFile file) {
        long startTime = System.currentTimeMillis();

        log.debug("Starting NSFW content analysis for file: {} ({}bytes)",
                file.getOriginalFilename(), file.getSize());

        try {
            int imageCount = countImagesInZip(file);

            // TODO: Implement actual NSFW detection service integration
            // This is a placeholder implementation that always returns safe result
            log.debug("NSFW analysis placeholder - analyzing {} images", imageCount);

            // Simulate processing time
            Thread.sleep(100);

            long analysisTime = System.currentTimeMillis() - startTime;

            log.debug("NSFW analysis completed - {} images analyzed in {}ms - Result: SAFE",
                    imageCount, analysisTime);

            return NsfwCheckResult.safe(imageCount, analysisTime);

        } catch (Exception e) {
            long analysisTime = System.currentTimeMillis() - startTime;
            log.error("NSFW analysis failed after {}ms: {}", analysisTime, e.getMessage(), e);

            // In case of analysis failure, return safe result to not block legitimate uploads
            // This behavior should be reviewed based on business requirements
            return NsfwCheckResult.safe(0, analysisTime);
        }
    }

    /**
     * Counts the number of image files in a ZIP archive.
     *
     * @param file The ZIP file to analyze
     * @return Number of image files found
     */
    private int countImagesInZip(MultipartFile file) {
        int imageCount = 0;

        try (ZipInputStream zipStream = new ZipInputStream(file.getInputStream())) {
            ZipEntry entry;

            while ((entry = zipStream.getNextEntry()) != null) {
                if (!entry.isDirectory() && isImageFile(entry.getName())) {
                    imageCount++;
                }
                zipStream.closeEntry();
            }

        } catch (Exception e) {
            log.warn("Failed to count images in ZIP file: {}", e.getMessage());
        }

        return imageCount;
    }

    /**
     * Determines if a file is an image based on its extension.
     *
     * @param fileName The file name to check
     * @return true if file appears to be an image
     */
    private boolean isImageFile(String fileName) {
        if (fileName == null) return false;

        String lowerCaseFileName = fileName.toLowerCase();
        return lowerCaseFileName.endsWith(".jpg") ||
                lowerCaseFileName.endsWith(".jpeg") ||
                lowerCaseFileName.endsWith(".png") ||
                lowerCaseFileName.endsWith(".gif") ||
                lowerCaseFileName.endsWith(".bmp");
    }
}
