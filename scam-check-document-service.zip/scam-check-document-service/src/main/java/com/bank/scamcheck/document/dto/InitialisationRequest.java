package com.bank.scamcheck.document.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * Data Transfer Object for scam check initialization request.
 * Contains all information required to initialize a scam check journey
 * including payee details, reference information, and system context.
 */
@Schema(description = "Scam check initialization request")
public record InitialisationRequest(

        @Schema(description = "Brand identifier for ABC bank", example = "ABC_RETAIL")
        String abcBrand,

        @Schema(description = "Organization or bank identifier", example = "ABC_BANK", required = true)
        @NotBlank(message = "Organization ID is required")
        String orgId,

        @Schema(description = "Channel identifier (Web/Mobile)", example = "WEB")
        String abcChannel,

        @Schema(description = "Payee information", required = true)
        @NotNull(message = "Payee information is required")
        @Valid
        PayeeDto payee,

        @Schema(description = "Unique reference ID for the payer", example = "PAY-REF-123456", required = true)
        @NotBlank(message = "Reference ID is required")
        String referenceId,

        @Schema(description = "Calling system or module identifier", example = "PAYMENTS", required = true)
        @NotBlank(message = "System ID is required")
        String systemId
) {
    /**
     * Creates an InitialisationRequest with validation.
     */
    public InitialisationRequest {
        if (orgId != null) {
            orgId = orgId.trim();
        }
        if (referenceId != null) {
            referenceId = referenceId.trim();
        }
        if (systemId != null) {
            systemId = systemId.trim();
        }
    }
}