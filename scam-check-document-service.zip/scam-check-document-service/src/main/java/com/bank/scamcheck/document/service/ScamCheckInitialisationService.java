package com.bank.scamcheck.document.service;

import com.bank.scamcheck.document.dto.InitialisationRequest;
import com.bank.scamcheck.document.dto.InitialisationResponse;
import com.bank.scamcheck.document.exception.DocumentProcessingException;
import com.bank.scamcheck.document.util.Constants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Arrays; // ✅ ADDED MISSING IMPORT
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Service class for handling scam check initialization operations.
 *
 * === CHANGES FOR INITIALISATION START ===
 * This service manages the initialization of scam check journeys,
 * creating session IDs and preparing the system for document upload.
 *
 * Future plan: This service will be extracted to a separate microservice
 * for better separation of concerns and independent scaling.
 * === CHANGES FOR INITIALISATION END ===

 * @version 1.0.0
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ScamCheckInitialisationService {

    // In-memory store for reference IDs (in production, use Redis or database)
    private final ConcurrentMap<String, String> activeReferenceIds = new ConcurrentHashMap<>();

    @Value("${server.port:8080}")
    private String serverPort;

    @Value("${app.hostname:localhost}")
    private String hostname;

    /**
     * Initializes a new scam check session.
     *
     * This method creates a new session for scam check processing,
     * validates the request, generates a unique session ID, and
     * returns the document upload URL for the next step.
     *
     * @param request The initialization request with payee and system details
     * @return InitialisationResponse with session details and upload URL
     * @throws DocumentProcessingException if initialization fails
     */
    public InitialisationResponse initializeScamCheck(InitialisationRequest request) {
        long startTime = System.currentTimeMillis();

        log.info("Starting scam check initialization - ReferenceId: {}, SystemId: {}",
                request.referenceId(), request.systemId());

        try {
            // Step 1: Validate system ID
            validateSystemId(request.systemId());

            // Step 2: Check for duplicate reference ID
            validateReferenceId(request.referenceId());

            // Step 3: Validate payee details
            validatePayeeDetails(request);

            // Step 4: Generate unique session ID
            String sessionId = generateSessionId();

            // Step 5: Store reference ID to prevent duplicates
            activeReferenceIds.put(request.referenceId(), sessionId);

            // Step 6: Build document upload URL
            String documentUploadUrl = buildDocumentUploadUrl();

            long processingTime = System.currentTimeMillis() - startTime;

            log.info("Scam check initialized successfully - SessionId: {}, ReferenceId: {} in {}ms",
                    sessionId, request.referenceId(), processingTime);

            return InitialisationResponse.success(
                    sessionId,
                    documentUploadUrl,
                    request.referenceId(),
                    request.systemId(),
                    processingTime
            );

        } catch (DocumentProcessingException e) {
            long processingTime = System.currentTimeMillis() - startTime;
            log.error("Scam check initialization failed for ReferenceId: {} after {}ms: {}",
                    request.referenceId(), processingTime, e.getMessage());

            return InitialisationResponse.failure(
                    request.referenceId(),
                    request.systemId(),
                    e.getMessage(),
                    processingTime
            );

        } catch (Exception e) {
            long processingTime = System.currentTimeMillis() - startTime;
            log.error("Unexpected error during initialization for ReferenceId: {} after {}ms",
                    request.referenceId(), processingTime, e);

            throw new DocumentProcessingException("Initialization failed: " + e.getMessage(), e);
        }
    }

    /**
     * Validates the system ID against supported systems.
     */
    private void validateSystemId(String systemId) {
        boolean isValidSystemId = Arrays.stream(Constants.SUPPORTED_SYSTEM_IDS) // ✅ FIXED - now imports Arrays
                .anyMatch(supportedId -> supportedId.equals(systemId));

        if (!isValidSystemId) {
            throw new DocumentProcessingException(
                    "Unsupported system ID: " + systemId +
                            ". Supported systems: " + String.join(", ", Constants.SUPPORTED_SYSTEM_IDS));
        }
    }

    /**
     * Validates that the reference ID is unique.
     */
    private void validateReferenceId(String referenceId) {
        if (activeReferenceIds.containsKey(referenceId)) {
            throw new DocumentProcessingException(Constants.ERROR_DUPLICATE_REFERENCE_ID);
        }
    }

    /**
     * Validates payee details for completeness and format.
     */
    private void validatePayeeDetails(InitialisationRequest request) {
        var payee = request.payee();

        // Additional business validation beyond annotation validation
        if (payee.paymentAmount().compareTo(java.math.BigDecimal.ZERO) <= 0) {
            throw new DocumentProcessingException("Payment amount must be greater than zero");
        }

        // Add more business-specific validations as needed
        log.debug("Payee validation completed for: {} {}",
                payee.firstName(), payee.surname());
    }

    /**
     * Generates a unique session ID for the scam check process.
     */
    private String generateSessionId() {
        return UUID.randomUUID().toString();
    }

    /**
     * Builds the complete document upload URL.
     */
    private String buildDocumentUploadUrl() {
        return String.format("https://%s:%s%s", hostname, serverPort, Constants.DOCUMENTS_PATH);
    }

    /**
     * Checks if a session ID exists and is valid.
     * This method can be used by the document upload service.
     */
    public boolean isValidSession(String sessionId) {
        return activeReferenceIds.containsValue(sessionId);
    }

    /**
     * Cleanup method to remove completed sessions.
     * Should be called after successful document processing.
     */
    public void cleanupSession(String referenceId) {
        activeReferenceIds.remove(referenceId);
        log.debug("Cleaned up session for ReferenceId: {}", referenceId);
    }
}
