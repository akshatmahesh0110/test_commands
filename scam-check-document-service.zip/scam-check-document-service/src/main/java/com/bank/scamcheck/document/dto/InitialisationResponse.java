package com.bank.scamcheck.document.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.time.LocalDateTime;

/**
 * Data Transfer Object for scam check initialization response.
 * Provides the document upload URL and session information
 * required for the subsequent document upload process.
 */
@Schema(description = "Scam check initialization response")
public record InitialisationResponse(

        @Schema(description = "Initialization success status", example = "true")
        boolean success,

        @Schema(description = "Generated scam check session identifier",
                example = "550e8400-e29b-41d4-a716-446655440000")
        String scamCheckSessionId,

        @Schema(description = "Document upload URL for next step",
                example = "https://hostname:port/economic-crime-prevention/resolving-fraud/scamcheck/v1/documents")
        String documentUploadUrl,

        @Schema(description = "Reference ID provided in request", example = "PAY-REF-123456")
        String referenceId,

        @Schema(description = "Calling system identifier", example = "PAYMENTS")
        String systemId,

        @Schema(description = "Initialization timestamp", example = "2025-07-29T12:30:45")
        LocalDateTime initialisedAt,

        @Schema(description = "Processing time in milliseconds", example = "150")
        long processingTimeMs,

        @Schema(description = "Response message", example = "Scam check initialized successfully")
        String message
) {

    /**
     * Creates a successful initialization response.
     */
    public static InitialisationResponse success(String scamCheckSessionId,
                                                 String documentUploadUrl,
                                                 String referenceId,
                                                 String systemId,
                                                 long processingTimeMs) {
        return new InitialisationResponse(
                true,
                scamCheckSessionId,
                documentUploadUrl,
                referenceId,
                systemId,
                LocalDateTime.now(),
                processingTimeMs,
                "Scam check initialized successfully"
        );
    }

    /**
     * Creates a failure initialization response.
     */
    public static InitialisationResponse failure(String referenceId,
                                                 String systemId,
                                                 String errorMessage,
                                                 long processingTimeMs) {
        return new InitialisationResponse(
                false,
                null,
                null,
                referenceId,
                systemId,
                LocalDateTime.now(),
                processingTimeMs,
                errorMessage
        );
    }
}
