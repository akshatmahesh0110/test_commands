package com.bank.scamcheck.document.config;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * Google Cloud Storage configuration for the document service.

 * Configures GCS client with proper authentication and settings
 * optimized for high-throughput document operations.
 */
@Configuration
@Slf4j
public class GcsConfig {

    @Value("${gcs.project-id}")
    private String projectId;

    @Value("${gcs.credentials.path:#{null}}")
    private String credentialsPath;

    @Bean
    public Storage googleCloudStorage() throws IOException {
        log.info("Initializing Google Cloud Storage client for project: {}", projectId);

        StorageOptions.Builder storageOptionsBuilder = StorageOptions.newBuilder()
                .setProjectId(projectId);

        // Configure credentials if path is provided
        if (credentialsPath != null && !credentialsPath.isEmpty()) {
            GoogleCredentials credentials = GoogleCredentials
                    .fromStream(new FileInputStream(credentialsPath));
            storageOptionsBuilder.setCredentials(credentials);
        }

        Storage storage = storageOptionsBuilder.build().getService();

        log.info("Google Cloud Storage client initialized successfully");
        return storage;
    }
}
