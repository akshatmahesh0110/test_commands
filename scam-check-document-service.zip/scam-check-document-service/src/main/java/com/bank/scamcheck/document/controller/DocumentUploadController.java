package com.bank.scamcheck.document.controller;

import com.bank.scamcheck.document.dto.DocumentUploadRequest;
import com.bank.scamcheck.document.dto.DocumentUploadResponse;
// === CHANGES FOR INITIALISATION START ===
import com.bank.scamcheck.document.dto.InitialisationRequest;
import com.bank.scamcheck.document.dto.InitialisationResponse;
// === CHANGES FOR INITIALISATION END ===
import com.bank.scamcheck.document.service.DocumentUploadService;
// === CHANGES FOR INITIALISATION START ===
import com.bank.scamcheck.document.service.ScamCheckInitialisationService;
// === CHANGES FOR INITIALISATION END ===
import com.bank.scamcheck.document.util.Constants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * REST Controller for document upload operations in the scam check system.

 * This controller provides endpoints for uploading ZIP files containing images
 * for scam verification purposes. It handles file validation, NSFW checking,
 * and secure storage to Google Cloud Storage.

 * === CHANGES FOR INITIALISATION START ===
 * Updated to include initialization endpoint for scam check journey setup.
 * === CHANGES FOR INITIALISATION END ===
 * @version 1.0.0
 */
@RestController
@RequestMapping("/economic-crime-prevention/resolving-fraud/scamcheck/v1")
@RequiredArgsConstructor
@Validated
@Slf4j
@Tag(name = "Scam Check Service", description = "APIs for scam check initialization and document upload")
public class DocumentUploadController {

    private final DocumentUploadService documentUploadService;
    // === CHANGES FOR INITIALISATION START ===
    private final ScamCheckInitialisationService initialisationService;
    // === CHANGES FOR INITIALISATION END ===

    // === CHANGES FOR INITIALISATION START ===
    /**
     * Initializes a new scam check journey.
     *
     * This endpoint creates a new scam check session with payee details
     * and returns the document upload URL and session ID for subsequent operations.
     *
     * @param request The initialization request with payee and system details
     * @param httpRequest HTTP servlet request for header extraction
     * @return InitialisationResponse with session details and upload URL
     */
    @PostMapping(value = "/initialisation",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(
            summary = "Initialize scam check journey",
            description = "Creates a new scam check session with payee details and system information. " +
                    "Returns session ID and document upload URL for the next step."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Scam check initialized successfully",
                    content = @Content(schema = @Schema(implementation = InitialisationResponse.class))
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Invalid request - missing required fields or invalid data format"
            ),
            @ApiResponse(
                    responseCode = "409",
                    description = "Conflict - Reference ID already exists"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "Internal server error - initialization failed"
            )
    })
    public ResponseEntity<InitialisationResponse> initializeScamCheck(
            @Parameter(description = "Initialization request with payee and system details", required = true)
            @Valid @RequestBody InitialisationRequest request,
            HttpServletRequest httpRequest) {

        long startTime = System.currentTimeMillis();

        log.info("Scam check initialization request received - ReferenceId: {}, SystemId: {}",
                request.referenceId(), request.systemId());

        try {
            // Extract and add headers to request (for future use)
            InitialisationRequest enrichedRequest = enrichWithHeaders(request, httpRequest);

            log.debug("Processing initialization request for ReferenceId: {}",
                    enrichedRequest.referenceId());

            // Process the initialization
            InitialisationResponse response = initialisationService.initializeScamCheck(enrichedRequest);

            long processingTime = System.currentTimeMillis() - startTime;
            log.info("Scam check initialization completed for ReferenceId: {} in {}ms",
                    request.referenceId(), processingTime);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            long processingTime = System.currentTimeMillis() - startTime;
            log.error("Scam check initialization failed after {}ms: {}", processingTime, e.getMessage(), e);
            throw e; // Let global exception handler manage the response
        }
    }

    /**
     * Enriches the initialization request with header information.
     */
    private InitialisationRequest enrichWithHeaders(InitialisationRequest request, HttpServletRequest httpRequest) {
        String abcBrand = httpRequest.getHeader(Constants.HEADER_ABC_BRAND);
        String orgId = httpRequest.getHeader(Constants.HEADER_ORG_ID);
        String abcChannel = httpRequest.getHeader(Constants.HEADER_ABC_CHANNEL);

        // Use header values if provided, otherwise use request values
        return new InitialisationRequest(
                abcBrand != null ? abcBrand : request.abcBrand(),
                orgId != null ? orgId : request.orgId(),
                abcChannel != null ? abcChannel : request.abcChannel(),
                request.payee(),
                request.referenceId(),
                request.systemId()
        );
    }
    // === CHANGES FOR INITIALISATION END ===

    /**
     * Uploads a ZIP file containing images for scam check analysis.
     *
     * This endpoint accepts a ZIP file (max 30MB) containing up to 4 images
     * and processes them through NSFW validation before storing in GCS.
     * The operation is performed asynchronously for optimal performance.
     *
     * @param file The ZIP file containing images to upload
     * @param request HTTP servlet request for header extraction
     * @return DocumentUploadResponse with upload status and metadata
     */
    @PostMapping(value = "/documents",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(
            summary = "Upload document for scam check",
            description = "Uploads a ZIP file containing images for scam verification analysis. " +
                    "The file undergoes NSFW checking before being stored in secure cloud storage."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Document uploaded successfully",
                    content = @Content(schema = @Schema(implementation = DocumentUploadResponse.class))
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Invalid request - file size exceeded, invalid format, or missing headers"
            ),
            @ApiResponse(
                    responseCode = "422",
                    description = "Unprocessable entity - NSFW content detected"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "Internal server error - storage or processing failure"
            )
    })
    public ResponseEntity<DocumentUploadResponse> uploadDocument(
            @Parameter(description = "ZIP file containing images (max 30MB)", required = true)
            @RequestParam("file") MultipartFile file,
            HttpServletRequest request) {

        long startTime = System.currentTimeMillis();

        log.info("Document upload request received - File: {} ({}bytes)",
                file.getOriginalFilename(), file.getSize());

        try {
            // Extract and validate headers
            DocumentUploadRequest uploadRequest = extractHeaders(request);

            log.debug("Processing upload request for session: {}",
                    uploadRequest.scamCheckSessionId());

            // Process the upload asynchronously
            DocumentUploadResponse response = documentUploadService
                    .processDocumentUpload(file, uploadRequest);

            long processingTime = System.currentTimeMillis() - startTime;
            log.info("Document upload completed successfully for session: {} in {}ms",
                    uploadRequest.scamCheckSessionId(), processingTime);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            long processingTime = System.currentTimeMillis() - startTime;
            log.error("Document upload failed after {}ms: {}", processingTime, e.getMessage(), e);
            throw e; // Let global exception handler manage the response
        }
    }

    /**
     * Health check endpoint for the document upload service.
     *
     * @return Simple health status response
     */
    @GetMapping("/health")
    @Operation(
            summary = "Service health check",
            description = "Returns the health status of the scam check service"
    )
    public ResponseEntity<String> healthCheck() {
        return ResponseEntity.ok("Scam Check Service is healthy");
    }

    /**
     * Extracts and validates request headers into a DocumentUploadRequest DTO.
     *
     * @param request HTTP servlet request
     * @return Validated DocumentUploadRequest
     * @throws IllegalArgumentException if required headers are missing
     */
    private DocumentUploadRequest extractHeaders(HttpServletRequest request) {
        String abcBrand = request.getHeader(Constants.HEADER_ABC_BRAND);
        String orgId = request.getHeader(Constants.HEADER_ORG_ID);
        String abcChannel = request.getHeader(Constants.HEADER_ABC_CHANNEL);
        String scamCheckSessionId = request.getHeader(Constants.HEADER_SCAM_CHECK_SESSION_ID);

        log.debug("Extracted headers - OrgId: {}, SessionId: {}, Brand: {}, Channel: {}",
                orgId, scamCheckSessionId, abcBrand, abcChannel);

        // Create and validate the request object
        DocumentUploadRequest uploadRequest = new DocumentUploadRequest(
                abcBrand, orgId, abcChannel, scamCheckSessionId
        );

        // Additional validation for required headers
        if (orgId == null || orgId.trim().isEmpty()) {
            throw new IllegalArgumentException("Header '" + Constants.HEADER_ORG_ID + "' is required");
        }

        if (scamCheckSessionId == null || scamCheckSessionId.trim().isEmpty()) {
            throw new IllegalArgumentException("Header '" + Constants.HEADER_SCAM_CHECK_SESSION_ID + "' is required");
        }

        return uploadRequest;
    }
}