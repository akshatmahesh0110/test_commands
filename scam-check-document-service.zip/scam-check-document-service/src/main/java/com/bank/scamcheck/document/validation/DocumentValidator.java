package com.bank.scamcheck.document.validation;

import com.bank.scamcheck.document.exception.DocumentProcessingException;
import com.bank.scamcheck.document.util.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Document validation component for the scam check system.

 * This validator implements multi-layered validation including:
 * - File format and size validation
 * - ZIP content structure validation
 * - Image type and count validation
 * - Security-focused validation rules

 * The validator ensures that only safe, properly formatted content
 * is processed by downstream services.

 * @version 1.0.0
 */
@Component
@Slf4j
public class DocumentValidator {

    /**
     * Validates the uploaded file against all security and format requirements.

     * Performs comprehensive validation including:
     * - File presence and basic properties
     * - Size constraints (max 30MB)
     * - File type validation (ZIP only)
     * - Content-Type verification
     *
     * @param file The multipart file to validate
     * @throws DocumentProcessingException if validation fails
     */
    public void validateFile(MultipartFile file) {
        log.debug("Starting file validation - Name: {}, Size: {}bytes, ContentType: {}",
                file.getOriginalFilename(), file.getSize(), file.getContentType());

        // Check if file is present
        if (file.isEmpty()) {
            throw new DocumentProcessingException("Uploaded file is empty");
        }

        // Validate file size
        if (file.getSize() > Constants.MAX_FILE_SIZE) {
            log.warn("File size validation failed - Size: {}bytes, Max: {}bytes",
                    file.getSize(), Constants.MAX_FILE_SIZE);
            throw new DocumentProcessingException(Constants.ERROR_FILE_TOO_LARGE);
        }

        // Validate file type
        if (!isValidZipFile(file)) {
            log.warn("File type validation failed - ContentType: {}, OriginalFilename: {}",
                    file.getContentType(), file.getOriginalFilename());
            throw new DocumentProcessingException(Constants.ERROR_INVALID_FILE_TYPE);
        }

        log.debug("File validation completed successfully");
    }

    /**
     * Validates ZIP content and counts the number of image files.

     * This method performs deep content validation including:
     * - ZIP file structure integrity
     * - Image file type validation
     * - Image count constraints
     * - Path traversal attack prevention

     * @param file The ZIP file to validate and analyze
     * @return Number of valid image files found
     * @throws DocumentProcessingException if validation fails
     */
    public int validateAndCountImages(MultipartFile file) {
        log.debug("Starting ZIP content validation and image counting");

        int imageCount = 0;
        int totalEntries = 0;

        try (ZipInputStream zipStream = new ZipInputStream(file.getInputStream())) {
            ZipEntry entry;

            while ((entry = zipStream.getNextEntry()) != null) {
                totalEntries++;

                // Security check: prevent path traversal attacks
                if (entry.getName().contains("..") || entry.getName().startsWith("/")) {
                    log.warn("Potential path traversal attempt detected in ZIP entry: {}",
                            entry.getName());
                    throw new DocumentProcessingException("Invalid file path detected in ZIP");
                }

                // Skip directories
                if (entry.isDirectory()) {
                    continue;
                }

                // Check if entry is an image file
                if (isImageFile(entry.getName())) {
                    imageCount++;
                    log.debug("Found image file: {} (size: {}bytes)",
                            entry.getName(), entry.getSize());
                }

                zipStream.closeEntry();
            }

            log.debug("ZIP analysis completed - Total entries: {}, Images: {}",
                    totalEntries, imageCount);

            // Validate image count
            if (imageCount == 0) {
                throw new DocumentProcessingException("No image files found in ZIP archive");
            }

            if (imageCount > Constants.MAX_IMAGES_PER_ZIP) {
                log.warn("Too many images in ZIP - Found: {}, Max: {}",
                        imageCount, Constants.MAX_IMAGES_PER_ZIP);
                throw new DocumentProcessingException(
                        String.format("ZIP contains %d images, maximum allowed is %d",
                                imageCount, Constants.MAX_IMAGES_PER_ZIP));
            }

            return imageCount;

        } catch (DocumentProcessingException e) {
            throw e; // Re-throw business exceptions

        } catch (Exception e) {
            log.error("ZIP validation failed: {}", e.getMessage(), e);
            throw new DocumentProcessingException("Failed to validate ZIP file content: " + e.getMessage(), e);
        }
    }

    /**
     * Validates if the uploaded file is a valid ZIP file.
     *
     * @param file The file to validate
     * @return true if file is a valid ZIP file
     */
    private boolean isValidZipFile(MultipartFile file) {
        // Check content type
        String contentType = file.getContentType();
        if (contentType != null &&
                (contentType.equals("application/zip") ||
                        contentType.equals("application/x-zip-compressed"))) {
            return true;
        }

        // Check file extension as fallback
        String originalFilename = file.getOriginalFilename();
        return originalFilename != null &&
                originalFilename.toLowerCase().endsWith(".zip");
    }

    /**
     * Determines if a file is an image based on its name and extension.
     *
     * @param fileName The file name to check
     * @return true if file appears to be an image
     */
    private boolean isImageFile(String fileName) {
        if (fileName == null || fileName.trim().isEmpty()) {
            return false;
        }

        String lowerCaseFileName = fileName.toLowerCase().trim();

        // Check against supported image extensions
        return lowerCaseFileName.endsWith(".jpg") ||
                lowerCaseFileName.endsWith(".jpeg") ||
                lowerCaseFileName.endsWith(".png") ||
                lowerCaseFileName.endsWith(".gif") ||
                lowerCaseFileName.endsWith(".bmp");
    }
}