package com.bank.scamcheck.document.service;

import com.bank.scamcheck.document.dto.DocumentUploadRequest;
import com.bank.scamcheck.document.dto.DocumentUploadResponse;
import com.bank.scamcheck.document.dto.NsfwCheckResult;
import com.bank.scamcheck.document.exception.DocumentProcessingException;
import com.bank.scamcheck.document.util.Constants;
import com.bank.scamcheck.document.validation.DocumentValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.util.concurrent.CompletableFuture;

/**
 * Service class for handling document upload operations.

 * This service orchestrates the complete document processing workflow including:
 * - File validation and security checks
 * - NSFW content detection
 * - Cloud storage operations
 * - Asynchronous processing for high throughput

 * The service implements enterprise patterns for scalability, reliability,
 * and maintainability while ensuring optimal performance for high TPS scenarios.

 * @version 1.0.0
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class DocumentUploadService {

    private final GcsStorageService gcsStorageService;
    private final NsfwCheckService nsfwCheckService;
    private final DocumentValidator documentValidator;

    /**
     * Processes a document upload request with comprehensive validation and storage.
     * This method implements the complete workflow for document processing:
     * 1. Validates file format, size, and content
     * 2. Performs NSFW content analysis
     * 3. Stores validated content to GCS
     * 4. Returns detailed processing results
     * The operation is designed for high throughput scenarios and includes
     * detailed monitoring and error handling.
     *
     * @param file The multipart file to process
     * @param request The upload request with metadata
     * @return DocumentUploadResponse with processing results
     * @throws DocumentProcessingException if processing fails
     */
    public DocumentUploadResponse processDocumentUpload(MultipartFile file,
                                                        DocumentUploadRequest request) {
        long startTime = System.currentTimeMillis();
        String sessionId = request.scamCheckSessionId();

        log.info("Starting document processing for session: {} - File: {} ({}bytes)",
                sessionId, file.getOriginalFilename(), file.getSize());

        try {
            // Step 1: Validate the uploaded file
            documentValidator.validateFile(file);
            log.debug("File validation completed for session: {}", sessionId);

            // Step 2: Extract and count images from ZIP
            int imageCount = documentValidator.validateAndCountImages(file);
            log.debug("Found {} images in ZIP for session: {}", imageCount, sessionId);

            // Step 3: Perform NSFW check asynchronously
            CompletableFuture<NsfwCheckResult> nsfwCheckFuture =
                    performNsfwCheckAsync(file, sessionId);

            // Step 4: Prepare storage path
            String storagePath = buildStoragePath(sessionId);

            // Step 5: Wait for NSFW check completion
            NsfwCheckResult nsfwResult = nsfwCheckFuture.join();
            log.debug("NSFW check completed for session: {} - Safe: {}",
                    sessionId, !nsfwResult.nsfwDetected());

            // Step 6: Reject if NSFW content detected
            if (nsfwResult.nsfwDetected()) {
                log.warn("NSFW content detected for session: {} - Rejecting upload", sessionId);
                throw new DocumentProcessingException(Constants.ERROR_NSFW_CONTENT_DETECTED);
            }

            // Step 7: Store to GCS
            String finalStoragePath = gcsStorageService.storeDocument(file, storagePath);
            log.info("Document stored successfully for session: {} at path: {}",
                    sessionId, finalStoragePath);

            // Step 8: Build success response
            long processingTime = System.currentTimeMillis() - startTime;

            return DocumentUploadResponse.success(
                    sessionId,
                    finalStoragePath,
                    imageCount,
                    file.getSize(),
                    nsfwResult.nsfwDetected(),
                    processingTime
            );

        } catch (DocumentProcessingException e) {
            long processingTime = System.currentTimeMillis() - startTime;
            log.error("Document processing failed for session: {} after {}ms: {}",
                    sessionId, processingTime, e.getMessage());

            return DocumentUploadResponse.failure(sessionId, e.getMessage(), processingTime);

        } catch (Exception e) {
            long processingTime = System.currentTimeMillis() - startTime;
            log.error("Unexpected error during document processing for session: {} after {}ms",
                    sessionId, processingTime, e);

            throw new DocumentProcessingException("Document processing failed: " + e.getMessage(), e);
        }
    }

    /**
     * Performs NSFW content check asynchronously for optimal performance.
     *
     * @param file The file to check
     * @param sessionId Session identifier for logging
     * @return CompletableFuture with NSFW check result
     */
    @Async("documentProcessingExecutor")
    public CompletableFuture<NsfwCheckResult> performNsfwCheckAsync(MultipartFile file,
                                                                    String sessionId) {
        log.debug("Starting async NSFW check for session: {}", sessionId);

        try {
            NsfwCheckResult result = nsfwCheckService.checkNsfwContent(file);
            log.debug("Async NSFW check completed for session: {} - Result: {}",
                    sessionId, !result.nsfwDetected() ? "SAFE" : "UNSAFE");
            return CompletableFuture.completedFuture(result);

        } catch (Exception e) {
            log.error("NSFW check failed for session: {}: {}", sessionId, e.getMessage(), e);
            return CompletableFuture.failedFuture(e);
        }
    }

    /**
     * Builds the GCS storage path using the session ID.
     *
     * @param sessionId Scam check session identifier
     * @return Complete storage path
     */
    private String buildStoragePath(String sessionId) {
        return String.format("%s/%s/", Constants.GCS_BUCKET_NAME, sessionId);
    }
}
