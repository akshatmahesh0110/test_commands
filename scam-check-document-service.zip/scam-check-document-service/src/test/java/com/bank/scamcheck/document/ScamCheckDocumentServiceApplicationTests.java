package com.bank.scamcheck.document;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScamCheckDocumentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
