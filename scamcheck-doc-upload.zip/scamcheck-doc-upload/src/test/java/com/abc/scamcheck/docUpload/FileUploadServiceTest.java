/*
package com.abc.scamcheck.docUpload;

import com.abc.scamcheck.docUpload.service.NsfwCheckService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.concurrent.Executor;

@ExtendWith(MockitoExtension.class)
class FileUploadServiceTest {

    @Mock
    private GcsService gcsService;

    @Mock
    private NsfwCheckService nsfwCheckService;

    @Mock
    private Executor asyncExecutor;

    @InjectMocks
    private FileUploadService fileUploadService;

    @Test
    void testProcessUpload() throws IOException {
        // Setup
        String requestId = UUID.randomUUID().toString();
        MockMultipartFile mockFile = new MockMultipartFile(
                "file", "test.zip", "application/zip", createTestZipFile());

        UploadRequestDto requestDto = new UploadRequestDto();
        requestDto.setFile(mockFile);
        requestDto.setRequestId(requestId);

        when(nsfwCheckService.checkImage(any())).thenReturn(true);

        // Execute
        fileUploadService.processUpload(requestDto);

        // Verify
        verify(gcsService, atLeastOnce()).uploadFile(anyString(), any(File.class));
        verify(gcsService).writeJsonToTriggerBucket(eq(requestId + "/metadata.json"), anyMap());
    }

    private byte[] createTestZipFile() throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(baos)) {
            // Add test image
            ZipEntry entry = new ZipEntry("test.jpg");
            zos.putNextEntry(entry);
            zos.write("test image content".getBytes());
            zos.closeEntry();
        }
        return baos.toByteArray();
    }
}*/
