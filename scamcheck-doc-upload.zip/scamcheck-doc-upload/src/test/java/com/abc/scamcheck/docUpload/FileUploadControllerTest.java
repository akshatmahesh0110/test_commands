/*
package com.abc.scamcheck.docUpload;

@WebMvcTest(FileUploadController.class)
@Import({FileUploadService.class, GcsService.class, NsfwCheckService.class})
@AutoConfigureMockMvc
class FileUploadControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private FileUploadService fileUploadService;

    @Test
    void testUploadFile() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file", "test.zip", "application/zip", "test data".getBytes());

        String requestId = UUID.randomUUID().toString();

        mockMvc.perform(multipart("/api/v1/uploads")
                        .file(file)
                        .param("requestId", requestId))
                .andExpect(status().isAccepted());
    }

    @Test
    void testUploadFileInvalidRequestId() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file", "test.zip", "application/zip", "test data".getBytes());

        mockMvc.perform(multipart("/api/v1/uploads")
                        .file(file)
                        .param("requestId", "invalid-uuid"))
                .andExpect(status().isBadRequest());
    }
}*/
