package com.abc.scamcheck.docUpload.model.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;

@Data
public class UploadRequest {
    @NotNull(message = "Zip file cannot be null")
    private MultipartFile zipFile;

    @NotBlank(message = "Request ID cannot be empty")
    @Pattern(regexp = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
    private String requestId;

    public InputStream getZipStream() throws IOException {
        return this.zipFile.getInputStream(); // Streams directly from disk
    }
}
