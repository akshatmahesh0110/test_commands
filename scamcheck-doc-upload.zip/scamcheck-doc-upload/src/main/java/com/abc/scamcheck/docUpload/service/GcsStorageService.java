package com.abc.scamcheck.docUpload.service;

import com.abc.scamcheck.docUpload.exception.GcsOperationException;
import com.google.cloud.storage.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class GcsStorageService {
    private final Storage storage;
    private final String bucketName;
    private final String triggerBucketName;

    public GcsStorageService(Storage storage,
                             @Value("${spring.cloud.gcp.storage.bucket-name}") String bucketName,
                             @Value("${spring.cloud.gcp.storage.trigger-bucket-name}") String triggerBucketName) {
        this.storage = storage;
        this.bucketName = bucketName;
        this.triggerBucketName = triggerBucketName;
    }

    /**
     * Uploads file to GCS with production-grade features:
     * - Chunked upload (handles large files)
     * - Automatic content type detection
     * - MD5 hash verification
     * - Async execution
     */
    @Async("gcsUploadExecutor")
    public CompletableFuture<String> upload(String gcsPath, File file) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                BlobId blobId = BlobId.of(bucketName, gcsPath);
                BlobInfo blobInfo = BlobInfo.newBuilder(blobId)
                        .setContentType(detectContentType(file))
                        .build();

                // Chunked upload with automatic retry
                storage.createFrom(blobInfo, file.toPath(),
                        Storage.BlobWriteOption.detectContentType(),
                        Storage.BlobWriteOption.md5Match());

                String gcsUrl = "gs://" + bucketName + "/" + gcsPath;
                log.debug("Uploaded to {}", gcsUrl);
                return gcsUrl;
            } catch (IOException | StorageException e) {
                throw new GcsOperationException("Failed to upload " + gcsPath, e);
            }
        });
    }

    /**
     * Writes metadata to trigger bucket (synchronous for consistency)
     */
    public void writeMetadata(String requestId, String metadataJson) {
        try {
            BlobId blobId = BlobId.of(triggerBucketName, requestId + "/metadata.json");
            BlobInfo blobInfo = BlobInfo.newBuilder(blobId)
                    .setContentType("application/json")
                    .build();

            storage.create(blobInfo, metadataJson.getBytes());
        } catch (StorageException e) {
            throw new GcsOperationException("Failed to write metadata for " + requestId, e);
        }
    }

    private String detectContentType(File file) throws IOException {
        String detectedType = Files.probeContentType(file.toPath());
        return detectedType != null ? detectedType : "application/octet-stream";
    }

    /**
     * Gets public URL for uploaded file
     */
    public String getPublicUrl(String gcsPath) {
        return storage.get(bucketName, gcsPath).signUrl(7, java.util.concurrent.TimeUnit.DAYS).toString();
    }
}