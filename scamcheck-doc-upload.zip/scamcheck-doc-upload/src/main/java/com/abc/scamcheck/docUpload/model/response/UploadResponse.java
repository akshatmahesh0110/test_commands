package com.abc.scamcheck.docUpload.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.http.HttpStatus;

@Data
@AllArgsConstructor
public class UploadResponse {
    private String requestId;
    private String status;
    private HttpStatus httpStatus;
    private String gcsPath; // Format: "gs://bucket-name/requestId/"
}