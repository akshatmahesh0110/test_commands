package com.abc.scamcheck.docUpload.util;

import java.io.*;
import java.util.zip.*;
import java.util.function.BiConsumer;

public class ZipStreamProcessor {

    public static void process(InputStream zipStream,
                               BiConsumer<ZipEntry, InputStream> entryProcessor)
            throws IOException {

        try (ZipInputStream zis = new ZipInputStream(zipStream)) {
            ZipEntry entry;
            byte[] buffer = new byte[8192]; // 8KB buffer

            while ((entry = zis.getNextEntry()) != null) {
                if (!entry.isDirectory()) {
                    try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
                        int len;
                        while ((len = zis.read(buffer)) > 0) {
                            baos.write(buffer, 0, len);
                        }
                        try (InputStream entryStream = new ByteArrayInputStream(baos.toByteArray())) {
                            entryProcessor.accept(entry, entryStream);
                        }
                    }
                }
                zis.closeEntry();
            }
        }
    }
}