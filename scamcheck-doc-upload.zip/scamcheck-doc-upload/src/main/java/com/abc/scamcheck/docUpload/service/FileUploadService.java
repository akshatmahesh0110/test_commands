package com.abc.scamcheck.docUpload.service;

import com.abc.scamcheck.docUpload.model.request.UploadRequest;
import com.abc.scamcheck.docUpload.exception.GcsOperationException;
import com.abc.scamcheck.docUpload.util.ResourceCleanup;
import com.abc.scamcheck.docUpload.util.ZipStreamProcessor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;

@Service
@Slf4j
public class FileUploadService {

    private final GcsStorageService gcsService;
    private final NsfwCheckService nsfwCheckService;

    public FileUploadService(GcsStorageService gcsService,
                             NsfwCheckService nsfwCheckService) {
        this.gcsService = gcsService;
        this.nsfwCheckService = nsfwCheckService;
    }

    @Async("fileProcessingExecutor")
    public CompletableFuture<String> processUpload(UploadRequest request) {
        // Atomic container for temp directory path
        AtomicReference<Path> tempDirRef = new AtomicReference<>();

        try {
            // 1. Create isolated temp directory
            Path tempDir = Files.createTempDirectory("upload-" + request.getRequestId());
            tempDirRef.set(tempDir);
            log.debug("Created temp directory: {}", tempDir);

            // 2. Process zip stream
            try (InputStream zipStream = request.getZipStream()) {
                ZipStreamProcessor.process(zipStream, (entry, entryStream) -> {
                    Path currentDir = tempDirRef.get();
                    if (currentDir == null) {
                        throw new IllegalStateException("Temp directory not initialized");
                    }

                    if (!entry.isDirectory() && isImageFile(entry.getName())) {
                        try {
                            processZipEntry(entryStream, entry.getName(),
                                    request.getRequestId(), currentDir);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                });
            }

            // 3. Return GCS path pattern
            return CompletableFuture.completedFuture(
                    "gs://clean-image-bucket/" + request.getRequestId() + "/"
            );

        } catch (Exception e) {
            log.error("Upload failed for request {}", request.getRequestId(), e);
            throw new GcsOperationException("Upload processing failed", e);
        } finally {
            // 4. Cleanup resources
            Path tempDir = tempDirRef.get();
            if (tempDir != null) {
                cleanupTempDirectory(tempDir);
            }
            ResourceCleanup.cleanupMultipart(request.getZipFile());
        }
    }

    private void processZipEntry(InputStream entryStream,
                                 String filename,
                                 String requestId,
                                 Path tempDir) throws IOException {
        Path tempFile = null;
        try {
            // 1. Create temp file in our isolated directory
            tempFile = Files.createTempFile(tempDir, "img-", getFileExtension(filename));
            Files.copy(entryStream, tempFile);

            // 2. NSFW check (blocking call within async thread)
            if (nsfwCheckService.checkImage(tempFile.toFile()).join()) {
                // 3. Upload to GCS
                String gcsPath = requestId + "/" + filename;
                gcsService.upload(gcsPath, tempFile.toFile()).join();
                log.debug("Uploaded {} to GCS", gcsPath);
            } else {
                log.warn("NSFW content filtered: {}", filename);
            }
        } finally {
            ResourceCleanup.deleteTempFile(tempFile);
        }
    }

    private void cleanupTempDirectory(Path dir) {
        try {
            if (dir != null && Files.exists(dir)) {
                Files.walk(dir)
                        .sorted((a, b) -> -a.compareTo(b)) // Delete files before directories
                        .forEach(ResourceCleanup::deleteTempFile);
                log.debug("Cleaned up temp directory: {}", dir);
            }
        } catch (IOException e) {
            log.warn("Temp directory cleanup failed for {}", dir, e);
        }
    }

    private boolean isImageFile(String filename) {
        String lower = filename.toLowerCase();
        return lower.endsWith(".jpg") || lower.endsWith(".jpeg")
                || lower.endsWith(".png") || lower.endsWith(".gif");
    }

    private String getFileExtension(String filename) {
        int lastDot = filename.lastIndexOf('.');
        return lastDot > 0 ? filename.substring(lastDot) : ".tmp";
    }
}