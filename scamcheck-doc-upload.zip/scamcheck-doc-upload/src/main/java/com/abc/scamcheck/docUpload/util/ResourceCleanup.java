package com.abc.scamcheck.docUpload.util;

import jakarta.validation.constraints.NotNull;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;

public final class ResourceCleanup {

    public static void deleteTempFile(Path path) {
        if (path != null) {
            try {
                Files.deleteIfExists(path);
            } catch (IOException e) {
                // Log if needed
            }
        }
    }

    public static void cleanupMultipart(@NotNull(message = "Zip file cannot be null") MultipartFile file) {
        if (file != null && !file.isEmpty()) {
            try {
                file.transferTo(Paths.get("/dev/null")); // Linux-specific discard
            } catch (IOException ignored) {}
        }
    }
}