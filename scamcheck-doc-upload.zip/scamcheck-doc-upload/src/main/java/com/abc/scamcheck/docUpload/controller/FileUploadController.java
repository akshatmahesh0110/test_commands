package com.abc.scamcheck.docUpload.controller;

import com.abc.scamcheck.docUpload.model.request.UploadRequest;
import com.abc.scamcheck.docUpload.model.response.UploadResponse;
import com.abc.scamcheck.docUpload.service.FileUploadService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/api/v1/uploads")
public class FileUploadController {

    private final FileUploadService uploadService;

    public FileUploadController(FileUploadService uploadService) {
        this.uploadService = uploadService;
    }

    @PostMapping(consumes = "multipart/form-data")
    public ResponseEntity<UploadResponse> uploadFile(
            @RequestPart("file") MultipartFile file,
            @RequestParam("requestId") String requestId) throws IOException {

        UploadRequest request = new UploadRequest();
        request.setZipFile(file);
        request.setRequestId(requestId);

        String gcsPath = String.valueOf(uploadService.processUpload(request));

        return ResponseEntity.accepted()
                .body(new UploadResponse(
                        requestId,
                        "Processing started",
                        HttpStatus.ACCEPTED,
                        gcsPath
                ));
    }
}