package com.abc.scamcheck.docUpload.exception;

public class GcsOperationException extends RuntimeException {
    public GcsOperationException(String message) {
        super(message);
    }

    public GcsOperationException(String message, Throwable cause) {
        super(message, cause);
    }
}