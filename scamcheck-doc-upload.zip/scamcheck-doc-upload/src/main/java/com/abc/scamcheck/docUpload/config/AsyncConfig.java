package com.abc.scamcheck.docUpload.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

@Configuration
@EnableAsync
public class AsyncConfig {

    /**
     * Configures dedicated thread pools for:
     * - File processing (high queue capacity)
     * - External HTTP calls (small queue + high threads)
     */
    @Bean(name = "fileProcessingExecutor")
    public Executor fileProcessingExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(20);          // Baseline threads
        executor.setMaxPoolSize(100);           // Scale up under load
        executor.setQueueCapacity(500);         // Buffer for bursts
        executor.setThreadNamePrefix("file-proc-");
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        executor.initialize();
        return executor;
    }

    @Bean(name = "httpRequestExecutor")
    public Executor httpRequestExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(50);           // More threads for IO waits
        executor.setMaxPoolSize(200);
        executor.setQueueCapacity(100);         // Fail fast when overloaded
        executor.setThreadNamePrefix("http-req-");
        executor.initialize();
        return executor;
    }
}
