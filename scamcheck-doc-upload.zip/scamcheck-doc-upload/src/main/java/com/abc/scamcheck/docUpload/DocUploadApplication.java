package com.abc.scamcheck.docUpload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocUploadApplication {
    public static void main(String[] args) {
        SpringApplication.run(DocUploadApplication.class, args);
    }
}