package com.abc.scamcheck.docUpload.service;

import ch.qos.logback.classic.Logger;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpHeaders;

import java.io.File;
import java.util.concurrent.CompletableFuture;

@Service
@RequiredArgsConstructor
@Slf4j
public class NsfwCheckService {

    private final RestTemplate restTemplate;
    private final CircuitBreaker circuitBreaker;

    /**
     * Makes HTTP calls with:
     * - Timeouts
     * - Circuit breaker
     * - Retry logic
     */
    @Async("httpRequestExecutor")
    public CompletableFuture<Boolean> checkImage(File imageFile) {
        return CompletableFuture.supplyAsync(() -> {
/*            try {
                return circuitBreaker.executeSupplier(() -> {
                    HttpHeaders headers = new HttpHeaders();
                    headers.setContentType(MediaType.MULTIPART_FORM_DATA);

                    MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
                    body.add("file", new FileSystemResource(imageFile));

                    ResponseEntity<NsfwCheckResponse> response = restTemplate.exchange(
                            "http://nsfw-service/check",
                            HttpMethod.POST,
                            new HttpEntity<>(body, headers),
                            NsfwCheckResponse.class
                    );

                    return !response.getBody().isNsfw();
                });
            } catch (Exception e) {
                log.error("NSFW check failed", e);
                return true; // Fail-safe
            }*/

            // TODO: Uncomment above code and Call external NSFW microservice (stubbed for now)
            return true;
        });
    }
}