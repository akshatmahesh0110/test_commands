# Document Upload Microservice

Microservice for handling document uploads for scam check system.

## Features

- Accepts zip files containing images (up to 30MB)
- Processes files asynchronously for high throughput
- Stores unzipped images in GCS bucket
- Performs NSFW content check before storage
- Writes metadata to trigger bucket for downstream processing
- Handles high TPS (1000+ requests per second)

## API Documentation

See the [API Specification](api-spec.yaml) for detailed endpoint documentation.

## Local Development

### Prerequisites

- Java 17+
- Maven 3.8+
- GCP credentials with access to storage buckets

### Running the application

```bash
mvn spring-boot:run